Install from NuGet - [https://nuget.org/packages/Web.Ajax](https://nuget.org/packages/Web.Ajax) or manually by:

## Setting up to use Web.Ajax
# Download Web.Ajax.dll
# Add a reference to Web.Ajax.dll in your web project.
# Add the following handler to your web.config
{code:xml}
<!--For Classic application pools-->
<system.web>
    <httpHandlers>
	<remove verb="*" path="resource.axd" />
	<add verb="GET,HEAD" path="resource.axd" type="Web.Ajax.Handlers.Resource" validate="true" />
    </httpHandlers>
</system.web>

<!--For Integrated application pools-->
<system.webServer>
    <handlers>
        <add name="ResourceHandler" path="resource.axd" verb="*" type="Web.Ajax.Handlers.Resource,Web.Ajax" resourceType="Unspecified" preCondition="integratedMode" />
    </handlers>
</system.webServer>
{code:xml}

## Setting up to use the Controls
# In addition to the above add the following to your web.config to use the controls
{code:xml}
<system.web>
    <pages>
        <controls>
            <add tagPrefix="c" namespace="Web.Ajax.Controls" assembly="Web.Ajax" />
        </controls>
    </pages>
</system.web>
{code:xml}

## Don't Forget
# Change your page class to inherit from Web.Ajax.Page (instead of System.Web.UI.Page)
