# First read [Setup](Setup).

The Ajax Tree is an Asp.Net control for rendering a Tree where the data for each node can be retrieved from an AJAX request.

In your .aspx file
{code:html}
<c:Tree runat="server" ID="MyTree" />
{code:html}

In your .aspx.cs code behind file
{code:c#}
using Web.Ajax;
using Web.Ajax.Controls;

//Inherit your page class from Web.Ajax.Page
public partial class Default : Web.Ajax.Page
{
    public static TreeData[]() GetTree(TreeInfo ti)
    {
        if (string.IsNullOrEmpty(ti.Path))	//Get the root level
        {
            return new TreeData[](){
                new TreeData(){
                    Id="1",		
                    Title="Root 1",
                    Ajax=true //Get the children of this node using ajax
                },
                new TreeData(){
                    Id="2",
                    Title="Root 2",
                    Ajax=true
		}
            };
        }
        else
        {
             switch (ti.Path)
             {
                 case "1":
                      return new TreeData[](){
                          new TreeData(){
                              Id="1/1",
                              Title="Root 1, Child 1",
                              Ajax=true
                          },
                          new TreeData(){
                              Id="1/2",
                              Title="Root 1, Child 2"
                          }
                      };
                 case "2":
                     return new TreeData[](){
                         new TreeData(){
                             Id="2/1",		
                             Title="Root 2, Child 1"
                         },
                         new TreeData(){
                             Id="2/2",
                             Title="Root 2, Child 2"
                         }
                     };
                 case "1/1":
                     return new TreeData[](){
                         new TreeData(){
                             Id="1/1/1",		
                             Title="Root 1, Child 1, Sub Child 1"
                         },
                         new TreeData(){
                            Id="1/1/2",
                            Title="Root 1, Child 1, Sub Child 1"
                      }
                 };
            }
        }
        return null;
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        //Assign the DataMethod on the tree control
        MyTree.DataMethod = GetTree;
    }
}
{code:c#}

