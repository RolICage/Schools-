# First read [Setup](Setup).

The Ajax Grid is an Asp.Net control that renders a table dynamically on the client after getting the data using an AJAX request from the server.

Features:
* Paging
* Sorting
* Options Popup Menu

# A simple Ajax Grid sample

In your .aspx file
{code:html}
<c:AjaxGrid runat="server" ID="MyFirstGrid" 
	JavascriptId="MyFirstGrid"
	NoData="No Data found"
	RowsPerPage="5">
		<c:GridColumn runat="server" Name="First Name" Binding="FirstName" />
		<c:GridColumn runat="server" Name="Last Name" Binding="LastName" />
		<c:GridColumn runat="server" Name="Age" Binding="Age" />
</c:AjaxGrid>
{code:html}

In the code behind for your page (the .aspx.cs file)
{code:c#}
using Web.Ajax;
using Web.Ajax.Controls;

public partial class Default : Web.Ajax.Page
{
    /*
    The Data method must:
        1. be a static method
        2. take one parameter of type GridInfo
        3. return a DataTable
    */
    public static System.Data.DataTable GetGrid(GridInfo gi)
    {
	gi.NewTable();
	gi.AddColumns("FirstName", "LastName", "Age");

	gi.AddRow("John", "Murphy", "25");
	gi.AddRow("Peter", "Jones", "40");
	gi.AddRow("Ann", "Murphy", "39");
	gi.AddRow("Michael", "Johnston", "18");
	gi.AddRow("James", "Norton", "25");
	gi.AddRow("Homer", "Simpson", "42");
	gi.AddRow("Eric", "Cartman", "8");

	return gi.GetTable();
    }

    //Assign the Grid's DataMethod in the Page_Load 
    protected void Page_Load(object sender, EventArgs e)
    {
	MyFirstGrid.DataMethod = GetGrid;
    } 
}
{code:c#}

