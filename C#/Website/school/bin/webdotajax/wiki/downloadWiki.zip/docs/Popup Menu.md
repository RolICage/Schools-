# First read [Setup](Setup).

The Popup Menu is an Asp.Net control for positioning a block of html relative to another on the page.

A simple sample
{code:html}
<ul style="margin: 0; padding:0;list-style-type: none;">
    <li id="home" style="display:inline;border:1px solid #ccc;margin: 0; padding:5px;">Home</li>
    <li id="about" style="display:inline;border:1px solid #ccc;margin: 0; padding:5px;">About</li>
</ul>

<c:PopupMenu runat="server" JavascriptId="HomePopupMenu" SourceId="home">
    <div class="PopupMenu">
        <div class="MenuItem">Home Item 1</div>
        <div class="MenuItem">Home Item 2</div>
    </div>		
</c:PopupMenu>
<c:PopupMenu runat="server" JavascriptId="AboutPopupMenu" SourceId="about" >
    <div class="PopupMenu">
        <div class="MenuItem">About Item 1</div>
        <div class="MenuItem">About Item 2</div>
    </div>		
</c:PopupMenu>
{code:html}

