Web.Ajax contains functionality for converting CLI object to and from Json easily.

Consider the following class
{code:c#}
public class MyClass
{
    public string String;
    public int Number;
}
{code:c#}

To convert to Json
{code:c#}
var myObject = new MyClass()
{
    String = "test string",
    Number = 5
};
	
var jsonString = Web.Ajax.Json.ConvertToJson(myObject);
{code:c#}

To convert from Json
{code:c#}
var jsonString=@"{
	String: 'test string',
	Number: 5
}";
			
var myObject = Web.Ajax.Json.ConvertFrom<MyClass>(jsonString);
{code:c#}
