# First read [Setup](Setup).

The Popup Window is an Asp.Net control for simulating a windows style popup on a web page.

Features:
* Supports modal and non modal popup windows
* Content can be another page (rendered in an iframe)

A simple sample
{code:html}
<input type="button" onclick="MyPopupWindow.Show();" value="Show Popup Window" />

<c:Popup runat="server" ID="MyPopupWindow" JavascriptId="MyPopupWindow">
    <title>
        <left>Popup Title</left>
	<right></right>
    </title>
    <div style="width: 500px; height:200px;">
 	Put the popup window content here!
    </div>
</c:Popup>
{code:html}


Loading another page sample
{code:html}
<input type="button" onclick="ShowPopup();" value="Show Popup Window" />

<c:Popup runat="server" ID="MyPopupWindow" JavascriptId="MyPopupWindow">
    <title>
        <left></left>
	<right></right>
    </title>
</c:Popup>

<script type="text/javascript">
function ShowPopup() {
	MyPopupWindow.ShowPage(
		'http://webdotajax.codeplex.com', //url to load
		'Popup window Title',       //title
		800,                        //width
		800,                        //height
		function () {               //function to call when popup window is closed
			alert('Popup window has been closed!');
		}
	);
}
</script>
{code:html}

