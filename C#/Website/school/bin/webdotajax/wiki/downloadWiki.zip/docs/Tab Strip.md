# First read [Setup](Setup).

The Tab Strip control.

A simple sample
{code:html}
<c:TabStrip runat="server" >
    <c:Tab ID="Tab1" runat="server" Title="Tab 1" Selected="true">
        Tab 1 content here!
    </c:Tab>
    <c:Tab ID="Tab2" runat="server" Title="Tab 2">
        Tab 2 content here!
    </c:Tab>
    <c:Tab ID="Tab3" runat="server" Title="Tab 3">
        Tab 3 content here!
    </c:Tab>
</c:TabStrip>
{code:html}

