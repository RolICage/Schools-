# Web.Ajax
An easy to use AJAX library for .Net. 
* [Ajax Functionality](Ajax-Functionality) (using static Ajax methods)
* [Ajax Functionality (using interfaces and Inversion of Control)](Ajax-Functionality-(using-interfaces-and-Inversion-of-Control))
* [Json](Json)
Features a set of AJAX enabled controls including the following
* [Ajax Grid](Ajax-Grid) 
* [Ajax Tree](Ajax-Tree)
* [Popup Window](Popup-Window)
* [Popup Menu](Popup-Menu)
* [Tab Strip](Tab-Strip)
 

Works with Asp.Net 4.0 Web Form Applications.

Not suitable for MVC framework applications.


