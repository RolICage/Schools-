## First read [Setup](Setup) and  [Ajax Functionality](Ajax-Functionality).

Web.Ajax supports Inversion of Control, allowing you to put your Ajax methods into interfaces.
You can map interfaces to implementations in your Global.asax allowing you to write testable Ajax methods rather than relying on static methods.

{code:c#}
using Web.Ajax;

public interface IAjaxMethods
{
    [Ajax(Name="Ajax.SampleMethod")](Ajax(Name=_Ajax.SampleMethod_))    //The Name identifies the method on the client
    int SampleMethod(int a, int b)
}

public class AjaxMethods : IAjaxMethods
{
    public int SampleMethod(int a, int b)
    {
        return a*b;
    }
}
{code:c#}

In your Global.asax
{code:c#}
public class Global : System.Web.HttpApplication
{
    protected void Application_Start(object sender, EventArgs e)
    {
        Web.Ajax.InversionOfControl.Container.Instance.Map<IAjaxMethods, AjaxMethods>();
    }
...
{code:c#}

In your page class you register the interface containing the Ajax methods
{code:c#}
using Web.Ajax;

public partial class Default : Web.Ajax.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Ajax.RegisterAjaxMethods(this, typeof(IAjaxMethods));
    }
}
{code:c#}
