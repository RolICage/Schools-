﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI.WebControls;

namespace Web.Ajax.Controls
{
	public class select : DropDown
	{
		public select()
		{
			SelectOption = true;
		}

		public bool required
		{
			get;
			set;
		}

		public bool AllOption
		{
			get;
			set;
		}

		public bool SelectOption
		{
			get;
			set;
		}

		public string pid
		{
			get;
			set;
		}

		public string value
		{
			get;
			set;
		}

		public System.Type Type
		{
			get;
			set;
		}


		protected override void Render(System.Web.UI.HtmlTextWriter writer)
		{
			if (Type != null)
				Populate(this, this.Type, AllOption, SelectOption);
			else
			{
				if (AllOption)
				{
					Items.Insert(0, new ListItem("All", "-1"));
					SelectedValue = "-1";
				}
				if (SelectOption)
				{
					Items.Insert(0, new ListItem("Select...", ""));
					SelectedValue = "";
				}
			}
			var attributes = WebControl.GetAttributeString(this);
			writer.Write("<select id=\"" + pid + "\" "+attributes+" required=\""+(required?"true":"false")+"\" "+(Enabled?"":"disabled")+" >");
			foreach (ListItem item in this.Items)
			{
				var text = item.Text;
				if (text != null)
					text = text.Replace("_", " ");
				writer.Write("<option value=\"" + item.Value + "\" " + ((item.Value == SelectedValue || item.Value==value)? "selected" : "") + " >" + text + "</option>");
			}
			writer.Write("</select>");
		}

		public void AddItem(string text, string value, bool selected)
		{
			Items.Add(new ListItem() {  Text=text,Value=value, Selected=selected });
		}
		public void AddItem(string text, string value)
		{
			Items.Add(new ListItem() { Text = text, Value = value});
		}

	}
}
