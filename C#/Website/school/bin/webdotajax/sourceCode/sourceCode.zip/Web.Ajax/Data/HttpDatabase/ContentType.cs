﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Web.Ajax.Data.HttpDatabase
{
	public class ContentType
	{
		public long Id;
		public string Extension;
		public string HttpValue;

		public static ContentType Json = new ContentType(){ Id=1000, Extension=".json", HttpValue="application/json"};


		public static ContentType GetByHttpValue(string HttpValue)
		{
			var ct=(from c in ContentTypes where c.HttpValue == HttpValue select c).FirstOrDefault();
			if (ct == null)
				ct = Json;	//The Default Content Type is assumed to be json if none is supplied.
			return ct;
		}

		public static List<ContentType> ContentTypes = new List<ContentType>();
		static ContentType()
		{
			ContentTypes.Add(Json);
		}
	}
}
