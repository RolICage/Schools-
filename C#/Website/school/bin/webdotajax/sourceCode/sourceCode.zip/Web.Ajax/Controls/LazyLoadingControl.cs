using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Reflection;

namespace Web.Ajax.Controls
{
    [ToolboxData("<{0}:LazyLoadingControl runat=\"server\" />")]
    [ParseChildren(false)]
    public class LazyLoadingControl : AjaxControl
    {
        /// <summary>
        /// The signature for the static method used to return the Lazy Loading html.
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public delegate string GetDataMethod(LazyLoadingInfo TreeInfo);
        public GetDataMethod DataMethod;


        protected override void OnInit(EventArgs e)
        {
            Ajax.RegisterAjaxMethods(this);
            base.OnInit(e);
            if (Page != null)
            {
				Page.RegisterJavascriptFile(Resources.Javascript.AjaxControl);
				Page.RegisterJavascriptFile(Resources.Javascript.LazyLoading);
            }

        }

        protected override void Render(HtmlTextWriter writer)
        {           
            writer.WriteLine("<div id=\""+JavascriptId+"\" class=\""+(CssClass==null?"":CssClass)+"\" ></div>");
            writer.WriteLine("<script type=\"text/javascript\">");
            writer.WriteLine("var " + JavascriptId + " = new LazyLoading('" + JavascriptId + "','" + DataMethod.Method.DeclaringType.AssemblyQualifiedName + "','" + DataMethod.Method.Name + "');");
            RenderProperty(writer, "NoData", NoData);
            RenderParameters(writer);
            RenderJavascriptId(writer);
            //writer.WriteLine(JavascriptId+".GetData();");
            writer.WriteLine("</script>");
        }

        [Ajax]
        public static LazyLoadingResponse GetData(LazyLoadingRequest request)
        {
            LazyLoadingResponse response= new LazyLoadingResponse();
            try
            {
                Type Type = System.Type.GetType(request.DataMethodType);
                if (Type == null)
                    throw new Exception("LazyLoadingControl: Invalid Type.");
                MethodInfo Method = Type.GetMethod(request.DataMethodName);
                if (request.LazyLoadingInfo.Parameters == null)
                    request.LazyLoadingInfo.Parameters = new Parameter[0];
                object o = null;
                o = Method.Invoke(null, new object[] { request.LazyLoadingInfo });
                response.Data = (string)o;
				response.OnComplete = request.LazyLoadingInfo.OnComplete;
            }
            catch (Exception e)
            {
                if (e.InnerException != null)
                    response.Message = e.InnerException.Message;
                else
                    response.Message = e.Message;
            }
            return response;
        }
    }


    public class LazyLoadingInfo : ControlInfo
    {
    }

    public class LazyLoadingRequest : AjaxControlRequest
    {
        public LazyLoadingInfo LazyLoadingInfo;
    }

    public class LazyLoadingResponse : AjaxControlResponse
    {
        public string Data;
		public string OnComplete;
    }
}
