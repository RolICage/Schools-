using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Web.UI;

namespace Web.Ajax.Controls
{
    [ToolboxData("<{0}:Validator runat=\"server\" SourceId=\"?\" />")]
    public class Validator : WebControl
    {
        private string regEx;
        public string RegEx
        {
            get { return regEx; }
            set { regEx = value; }
        }

        private string sourceId;
        public string SourceId
        {
            get { return sourceId; }
            set { sourceId = value; }
        }
        public string ClientSourceId
        {
            get
            {
                if (Parent.ID == SourceId)					//Is the parent the source control(as would be the case for a sub menu)
                    return WebControl.GetJavascriptId(Parent);
                Control c = Parent.FindControl(SourceId);	//Is the source control in the parents naming container.
                if (c != null)
                    return WebControl.GetJavascriptId(c);						//No server control found, assume the SourceId is the ClientSourceId
                return SourceId;
            }
        }

        private bool required;
        public bool Required
        {
            get { return required; }
            set { required = value; }
        }

        private string function;
        public string Function
        {
            get { return function; }
            set { function = value; }
        }

        private string message;
        public string Message
        {
            get { return message; }
            set { message = value; }
        }

        private string group;
        public string Group
        {
            get { return group; }
            set { group = value; }
        }

        private string propertyName;
        public string PropertyName
        {
            get { return propertyName; }
            set { propertyName = value; }
        }

        private string matchId;
        public string MatchId
        {
            get { return matchId; }
            set { matchId = value; }
        }

        private string type;
        public string Type
        {
            get { return type; }
            set { type = value; }
        }

        public Validator()
        {
            if (Configuration.Settings.Current.ValidatorType != null)
                Type = Configuration.Settings.Current.ValidatorType;
        }

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);            
            if (Page != null)
            {
				Page.RegisterJavascriptFile(Resources.Javascript.Calendar);
				Page.RegisterJavascriptFile(Resources.Javascript.Validator);
                if (Type == "Popup")
                {
					Page.RegisterJavascriptFile(Resources.Javascript.AjaxControl);
                    Page.RegisterJavascriptFile(Resources.Javascript.PopupMenu);
                    Page.RegisterStyleSheet(Resources.StyleSheets.PopupMenu);
                }
            }
        }       

        protected override void Render(System.Web.UI.HtmlTextWriter writer)
        {
            if(Type=="Image")
                writer.WriteLine("<img id=\"" + JavascriptId + "\" src=\"" + Resources.ImageUrl(Resources.Images.Failure) + "\" style=\"visibility:hidden;\" />");
            RenderJavascriptStartTag(writer);
            writer.WriteLine("var "+JavascriptId+"=new Validator('"+JavascriptId+"');");
            if (!String.IsNullOrEmpty(SourceId))
                RenderProperty(writer, "SourceId", ClientSourceId);
            if (!String.IsNullOrEmpty(RegEx))
                RenderProperty(writer, "RegEx", RegEx);
            if (!String.IsNullOrEmpty(Message))
                RenderProperty(writer, "Message", Message);
            RenderProperty(writer, "Required", Required);
            if (!String.IsNullOrEmpty(Function))
                RenderProperty(writer, "Function", Function);
            if (!string.IsNullOrEmpty(Group))
                RenderProperty(writer, "Group", Group);
            if (!string.IsNullOrEmpty(PropertyName))
                RenderProperty(writer, "PropertyName", PropertyName);
            if (!string.IsNullOrEmpty(MatchId))
                RenderProperty(writer, "MatchId", MatchId);
            if (!string.IsNullOrEmpty(Type))
                RenderProperty(writer, "Type", Type);
            RenderJavascriptId(writer);
            RenderJavascriptEndTag(writer);
        }
    }
}
