﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Web.Ajax.Data
{
	public class Date
	{
		public static DateTime? GetEndOfDay(DateTime? dt)
		{
			if (!dt.HasValue)
				return null;
			return new DateTime(dt.Value.Year, dt.Value.Month, dt.Value.Day, 23, 59, 59);
		}

		public static DateTime? GetStartOfDay(DateTime? dt)
		{
			if (!dt.HasValue)
				return null;
			return new DateTime(dt.Value.Year, dt.Value.Month, dt.Value.Day, 0, 0, 0);
		}

		public static DateTime? GetStartOfNextDay(DateTime? dt)
		{
			if (!dt.HasValue)
				return null;
			return GetStartOfDay(dt.Value.AddDays(1));
		}

		public static DateTime GetStartOfYear(DateTime dt)
		{
			return new DateTime(dt.Year, 1, 1);
		}
	}
}
