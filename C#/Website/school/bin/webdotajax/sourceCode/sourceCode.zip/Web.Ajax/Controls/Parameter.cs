using System.Collections.Generic;
using System.Web.UI;

namespace Web.Ajax.Controls
{
	[ToolboxData("<{0}:Parameter Name=\"?\" Source=\"\" Value=\"\" />")]
    [Json(IgnoreParent=true)]
	public class Parameter : System.Web.UI.WebControls.WebControl
	{

		private string name="";
        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        private string source = "";
		public string Source
        {
            get { return source; }
            set { source = value; }
        }

		private string _value="";
        public string Value
        {
            get { return _value; }
            set { _value = value; }
        }

        public Parameter()
        {
        }

        public Parameter(string Name, string Value)
        {
            this.Name = Name;
            this.Value = Value;
        }

		public string ConvertToJson()
		{
			return	"{Name:" + Json.ConvertToJson(Name) +
					",Source:" + Json.ConvertToJson(Source) +
					",Value:" + Json.ConvertToJson(Value) +
					"}";
		}

        public static string GetValue(Parameter[] pars, string Name)
        {
            for (int i = 0; i < pars.Length; i++)
            {
                if (pars[i].Name == Name)
                    return pars[i].Value;
            }
            return null;
        }

        public static void AppendValue(Parameter[] pars, string Name, string Value)
        {
			List<Parameter> paramList = new List<Parameter>(pars);
			paramList.Add(new Parameter(Name, Value));
            pars = paramList.ToArray();
        }

        public static bool ModifyValue(Parameter[] pars, string Name, string NewValue, bool AppendIfNotFound)
        {
			bool found = false;
			foreach (Parameter p in pars)
                if (p.Name == Name)
				{
                    p.Value = NewValue;
					found = true;
				}
			if (AppendIfNotFound && !found)
			{
				AppendValue(pars, Name, NewValue);
				found = true;
			}
			return (found);
        }
    }
}