﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Web.Ajax.Data
{
	public static class Extensions
	{
		public static IEnumerable<T> Each<T>(this IEnumerable<T> l, Action<T> f)
		{
			if (l == null || f==null)
				return new T[]{};
			foreach(var o in l)
			{
				f(o);
			}
			return l;
		}
	}
}
