function Tabs(id)
{
	this.SelectedTabId=null;
	this.Tabs = null;
	this.ExpandPad = 15;

	this.GetTab=function(tid)
	{
		var lst=this.Tabs;
		if(!lst)
			return null;
		for(var i=0;i<lst.length;i++)
		{
			if(lst[i].ClientID==tid)
				return lst[i];
		}
		return null;
	}
	this.Select=function(nid, url)
	{
		var cid=this.SelectedTabId;
		el(cid+'_Content').style.display='none';
		el(cid+'_l').className='TabLeft';
		el(cid).className='TabMiddle';
		el(cid+'_r').className='TabRight';
		el(cid+'_b').className='TabFill';

		el(nid+'_Content').style.display='';
		el(nid+'_l').className='TabLeftSelected';
		el(nid).className='TabMiddleSelected';
		el(nid+'_r').className='TabRightSelected';
		el(nid+'_b').className='TabFillSelected';
		this.SelectedTabId=nid;

		if(url!=null)
		{
			var f=el(nid+'_Frame');
			if(f)
			{
				if(!f.src||f.src=='')
				{
					f.src=url;
				}
			}
		}
	}
	var expandcalledonce = false;
	this.Expand = function(force, min) {
		//force = true;
		if (min == null)
			min = this.MinHeight;

		if (!Tabs)
			return;
		if (min > -1) {
			for (var i = 0; i < this.Tabs.length; i++) {
				var t = this.Tabs[i];
				var c = el(t.Id + '_Content');
				if (c)
					c.style.height = min + 'px';
			}
		}

		var ds = GetDocSize();

		var nh;
		for (var i = 0; i < this.Tabs.length; i++) {
			var t = this.Tabs[i];
			t.Element = el(t.Id + '_Content');
			if (!t.Element || t.Id != this.SelectedTabId)
				continue;
			var rec = GetRec(t.Element);
			if (((rec.y + rec.h) < ds.h) || force)
				nh = (ds.h - rec.y - this.ExpandPad);
		}
		if (!nh)
			return;
		for (var i = 0; i < this.Tabs.length; i++) {
			var t = this.Tabs[i];
			if (t.Element)
				SetSize(t.Element, null, (nh + (t.ExpandPad ? (this.ExpandPad - t.ExpandPad) : 0)));
		}

		if (!expandcalledonce) {
			var ts = this;
			$(window).load(function() {
				ts.Expand();
			});
			if (this.Resize) {
				$(window).resize(function() {
					//ts.Expand();
					ts.ResizeEvent();
				});
				//AddResizeMethod(id, function() { ts.Expand(); });
			}
		}
		expandcalledonce = true;
	}
	this.ResizeEvent = function() {
		if(this.TimerId)
			clearTimeout(this.TimerId);
		this.TimerId = setTimeout(id+'.Expand();', 100);
	}
}
