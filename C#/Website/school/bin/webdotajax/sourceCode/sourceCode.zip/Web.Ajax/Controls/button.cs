﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Web.Ajax.Controls
{
	public class button : WebControl
	{
		public string image;
		public string text;
		public string onclick;

		protected override void Render(System.Web.UI.HtmlTextWriter writer)
		{

			//<button type="button" onclick="GetXml();" style="vertical-align: middle; padding: 0 2px;"><img src="resource.axd?Tag.gif" class="vam" />&nbsp;<span class="vam">ROS File</span></button>


			writer.Write("<button class=\"button\" type=\"button\" onclick=\""+onclick+"\" >");
			if(!string.IsNullOrEmpty(image))
				writer.Write("<img src=\""+Resources.ImageUrl(image)+"\" class=\"vam\" />&nbsp;");
			writer.Write("<span class=\"vam\">"+text+"</span>");
			writer.Write("</button>");
		}
	}
}
