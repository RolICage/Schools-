﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Web.Ajax.Testing
{
	public class TestProperty : Attribute
	{
	}
}
