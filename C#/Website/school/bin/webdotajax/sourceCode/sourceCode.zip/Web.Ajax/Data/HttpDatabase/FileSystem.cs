﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace Web.Ajax.Data.HttpDatabase
{
	public class FileSystem
	{
		public static string GetPhysicalPath(string path, string extension)
		{
			return Configuration.Settings.Current.DataFolder + path+extension;
		}
		public static string GetPhysicalPath(string path)
		{
			return GetPhysicalPath(path, null);
		}


		public static bool DoesFileExist(string path, string extension)
		{
			return File.Exists(GetPhysicalPath(path, extension));
		}

		public static string GetFileContent(string physicalPath)
		{
			using (var r = new StreamReader(physicalPath))
			{
				return r.ReadToEnd();
			}
		}

		public static void SaveFile(string physicalPath, string Content)
		{
			using (var w = new StreamWriter(physicalPath))
			{
				w.Write(Content);
			}
		}

	}
}
