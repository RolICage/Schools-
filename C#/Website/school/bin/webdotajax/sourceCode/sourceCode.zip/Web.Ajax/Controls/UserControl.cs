using System.Web.UI;

namespace Web.Ajax.Controls
{
	public class UserControl : System.Web.UI.UserControl
	{
		#region OnInit
		protected override void OnInit(System.EventArgs e)
		{
			Ajax.RegisterAjaxMethods(this);
			base.OnInit(e);
		}
		#endregion

        public new Web.Ajax.Page Page
        {
            get
            {
                return base.Page as Web.Ajax.Page;
            }
            set
            {
                base.Page = value;
            }
        }

		public string Json(object o)
		{
			return Web.Ajax.Json.ConvertToJson(o);
		}
	}
}