﻿function AjaxControl()
{
	this.Parameters=null;
	this.SetParameter=function(key,val)
	{
		if(!this.Parameters)
			this.Parameters=[]
		var p=this.Parameters;
		for(var i=0;i<p.length;i++)
		{
			if(p[i].Name==key)
			{
				p[i].Value=val;
				return;
			}
		}
		var np={};
		np.Name=key;
		np.Value=val;
		p[p.length]=np;
	}
	this.GetParameters = function () {
		var p = this.Parameters;
		if (p) {
			for (var i = 0; i < p.length; i++) {
				var e = el(p[i].Source);
				if (e == null)
					e = window[p[i].Source];
				if (e != null) {
					if (e.type == 'checkbox')
						p[i].Value = e.checked;
					else if (e.Type == 'Calendar')
						p[i].Value = e.Date;
					else if (e.value != null) 
						p[i].Value = e.value;

				}
			}
		}
		return p;
	}
	this.GetParameter = function(n) {
		var p = this.Parameters;
		if (p) {
			for (i = 0; i < p.length; i++) {
				if (p[i].Name == n)
					return p[i];
			}
		}
	}
}