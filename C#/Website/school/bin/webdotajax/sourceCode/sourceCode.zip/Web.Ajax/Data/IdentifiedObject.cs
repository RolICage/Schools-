﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Web.Ajax.Data
{
	public class IdentifiedObject
	{
		public object Clause;
		public object Values;
	}
}
