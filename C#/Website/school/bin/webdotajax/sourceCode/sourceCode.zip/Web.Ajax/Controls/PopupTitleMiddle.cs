using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace Web.Ajax.Controls
{
	/// <summary>
	/// Represents the Middle part of a Popup title bar. It gets rendered as a table cell and should be contained within 
	/// a PopupTitle Control.
	/// </summary>
	[ToolboxData("<{0}:PopupTitleMiddle runat=\"server\"></{0}:PopupTitleMiddle>")]
	[ControlBuilderAttribute(typeof(ControlBuilder))]
	[ParseChildren(false)] 
	public class PopupTitleMiddle : PopupTitlePart
	{
		#region Constructor
		/// <summary>
		/// Constructor
		/// </summary>
		public PopupTitleMiddle()
		{
			CssClass = "PopupTitleMiddle";
			ID = "Middle";
		} 
		#endregion
	}
}
