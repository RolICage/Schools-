using System;
using System.Collections.Generic;
using System.Text;

namespace Web.Ajax.Controls
{
    public enum Browser
    {
        Unknown,
        IE6,
        IE7,
		IE8,
		IE9,
        FireFox,
		Chrome
    }
}
