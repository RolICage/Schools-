﻿function SlidePanel(id)
{
	var Content=el(id);
	this.IntervalId;
	this.MaxHeight=200;
	var Height=0;
	this.SlideTime=100;
	this.StartTime=null;
	this.TickSpeed=30;
	this.Sliding=false;
	var s=GetSize(Content);
	this.MaxHeight=s.h;
	this.OnComplete=null;
	this.Dir;
	var o=this;

	Content.style.overflow='hidden';
	this.Show=function(OnComplete)
	{
		Content.style.height='1px';
		Content.style.display='block';
		this.Slide('d',OnComplete);
	}
	this.Hide=function(OnComplete)
	{
		this.Slide('u',OnComplete);
	}
	this.Slide=function(dir, OnComplete)
	{
		if(this.Sliding)
			return;
		this.Dir=dir;
		this.Sliding=true;
		this.OnComplete=OnComplete;
		this.StartTime=(new Date()).getTime();
		this.IntervalId=setInterval('SlidePanels[\''+id+'\'].Tick();',this.TickSpeed); 
	}
	this.Tick=function()
	{
		var elapsed = (new Date()).getTime() - this.StartTime; 
		if (elapsed > this.SlideTime)
		{
			this.Sliding=false;
			clearInterval(this.IntervalId);
			if(this.Dir=='u')
				Content.style.display='none';
			Content.style.height=this.MaxHeight+'px'; 

			if(this.OnComplete)
				this.OnComplete();
		}
		else 
		{
			var d =Math.round(elapsed / this.SlideTime * this.MaxHeight);
			if(this.Dir == 'u')
				d = this.MaxHeight - d;
		Content.style.height = d + 'px';
		}
		return;
	}
}
var SlidePanels={};
function CreateSlidePanel(id)
{
	var s=SlidePanels[id];
	if(s==null)
	{
		s=new SlidePanel(id);
		SlidePanels[id]=s;
	}
	return s;
}
