function DragDrop()
{
	var o=this;
	var DragObject  = null;
	var MouseOffset = null;
	var br;	//BottomRight
	var win=window;
	this.MouseMove=function(e)
	{
		if(!e)
			e=window.event;
		if(DragObject)
		{
			var p = GetMouseCoords(e);			
			var t=p.y - MouseOffset.y;
			var l=p.x - MouseOffset.x;
			var s=GetSize(DragObject);
			var ds=GetDocSize(win);
			if(l<0)
			    l=0;
			if(l>(ds.w-s.w))
			    l=(ds.w-s.w);
			if(t<0)
			    t=0;
			if(t>(ds.h-s.h))
			    t=(ds.h-s.h);
			DragObject.style.left= l +'px';
			DragObject.style.top= t +'px';
			/*    
			if(l>0&&l<=(ds.w-s.w))
				DragObject.style.left= l +'px';
			if(t>0&&t<=(ds.h-s.h)) 
				DragObject.style.top= t +'px';*/
			return false;
		}
	}
	this.MouseUp=function()
	{
		DragObject = null;
		document.onmousemove=null;
		document.onmouseup=null;
		var b=el('Modal_Background');
		if(b)
		{
			b.contentWindow.document.onmousemove=null;
			b.contentWindow.document.onmouseup=null;
		}					
	}
	this.BeginDragging=function(t, e){DragObject=t;DragObject.style.position = 'absolute';if(!e)e=window.event;var docPos = GetPosition(t);var mousePos  = GetMouseCoords(e);MouseOffset= {x:mousePos.x - docPos.x, y:mousePos.y - docPos.y};br=GetPosition(t,'br');}
	this.MakeDragable=function(sid, tid)
	{
		if(tid==null)
			tid=sid;
		if(el(sid)==null||el(tid)==null)
			return;
		el(sid).onmousedown = function(e)
		{
			document.onmousemove=function(e){o.MouseMove(e);}
			document.onmouseup=function(e){o.MouseUp(e);}
			var b=el('Modal_Background');
			if(b)
			{
				b.contentWindow.document.onmousemove=function(e){o.MouseMove(e);}
				b.contentWindow.document.onmouseup=function(e){o.MouseUp(e);}
			}		
			
			o.BeginDragging(el(tid), e);
			return false;
		}
	}
}
var DragDrop=new DragDrop();