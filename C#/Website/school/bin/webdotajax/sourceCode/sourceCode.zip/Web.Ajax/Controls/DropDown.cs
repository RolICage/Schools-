using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

namespace Web.Ajax.Controls
{
    public class DropDown : System.Web.UI.WebControls.DropDownList
    {
        public static void Select(System.Web.UI.WebControls.DropDownList dropdown, string Value)
        {
            ListItem item=dropdown.Items.FindByValue(Value);
            if (item != null)
            {
                dropdown.SelectedValue = Value;
            }
        }


        public static string AddSpaces(string s)
        {
            for (int i = s.Length-1; i >-1; i--)
            {
                char c = s[i];
                if (Char.IsUpper(c))
                {
                    s=s.Insert(i, " ");
                }
            }
            return s;
        }

        public static void Populate(System.Web.UI.WebControls.DropDownList dropdown, Type t, bool all, bool select)
        {

            if (select)
                dropdown.Items.Add(new ListItem("Select...", ""));
            if (all)
                dropdown.Items.Add(new ListItem("All", ""));
            if (t.IsEnum)
            {
                IList vals = (IList)Enum.GetValues(t);
                for (int i = 0; i < vals.Count; i++)
                {
                    object val=vals[i];
                    ListItem item = new ListItem(Enum.GetName(t,val),val.ToString());
                    dropdown.Items.Add(item);
                }
                return;
            }
        }

        public static void Populate(System.Web.UI.WebControls.DropDownList dropdown, Type t)
        {
            Populate(dropdown, t, false, true);
        }

        public static void Populate(System.Web.UI.WebControls.DropDownList dropdown, Type t, bool all)
        {
            Populate(dropdown, t, true, false);
        }

    }
}
