﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Web.Ajax.Testing
{
	public class TestGroup : Attribute, IComparable
	{
		public int Order = int.MaxValue;
		public string Name;

		public int CompareTo(object o)
		{
			var g = (TestGroup)o;
			if (g == null)
				return -1;
			return Order.CompareTo(g.Order);
		}
	}
}
