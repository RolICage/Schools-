﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Web.Ajax.Controls
{
	public class MasterPage : System.Web.UI.MasterPage
	{
		public virtual string BaseUrl
		{
			get
			{
				return ResolveUrl("~/");
			}
		}

		private string lastUrlKey;
		private string LastUrlKey
		{
			get
			{
				if (lastUrlKey == null)
				{
					lastUrlKey = "Last." + GetType().Name + ".Url";
				}
				return lastUrlKey;
			}
		}

		public void RememberLastUrl()
		{
			if (Request.Url.AbsolutePath.ToLower() == (BaseUrl + "/default.aspx").ToLower())
			{
				if (Request.UrlReferrer != null && !Request.UrlReferrer.AbsolutePath.ToLower().StartsWith(BaseUrl.ToLower()))
				{
					var r = Session[LastUrlKey];
					if (r != null)
						Response.Redirect(r.ToString());
				}
				else
					Session[LastUrlKey] = null;
			}
			else
			{
				Session[LastUrlKey] = Request.Url;
			}
		}
	}
}
