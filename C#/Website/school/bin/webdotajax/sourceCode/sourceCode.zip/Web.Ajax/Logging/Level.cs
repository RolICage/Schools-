using System;
using System.Collections.Generic;
using System.Text;

namespace Web.Ajax.Logging
{
    public enum Level
    {
        Debug=1,
        Info = 2,
        Warn = 3,
        Error=4,
        Fatal=5
    }
}
