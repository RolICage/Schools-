using System;
using System.Collections.Generic;
using System.Text;

namespace Web.Ajax.Data
{
    public class Format
    {
		public enum Target
		{
			Html,
			Csv,
			Text
		}

        public static readonly string DateFormat = "dd-MMM-yyyy";
        public static readonly string DateTimeFormat = "dd-MMM-yyyy HH:mm";

        public static string Date(DateTime? dt, bool IncludeTime)
        {
            if (!dt.HasValue)
                return "";
            string format = DateFormat;
            if (IncludeTime)
                format = DateTimeFormat;
            return dt.Value.ToString(format);
        }

        public static string Date(DateTime? dt)
        {
            return Date(dt, false);
        }

        public static string Currency(Decimal? d, Target? t)
        {
			var prefix="";
			if (!t.HasValue)
				t = Target.Html;
			if(t == Target.Html)
				prefix="&euro;";
            if (d.HasValue)
                return  prefix + d.Value.ToString("N2");
            return "";
        }
		public static string Currency(Decimal? d){return Currency(d, Target.Html);}

        public static string Currency(double? d)
        {
            if (d.HasValue)
                return "&euro;" + d.Value.ToString("N2");
            return "";
        }

		public static string Amount(Decimal? d, Target? t)
		{
			if (!t.HasValue)
				t = Target.Html;
			if (d.HasValue)
				return d.Value.ToString("N2");
			return "";
		}


        public static string Percentage(Decimal? d)
        {
            if (d.HasValue)
                return d.Value.ToString("N2") + "%";
            return "";
        }

        public static string Enum(Enum e)
        {
            if (e==null)
                return "";
            return e.ToString();
        }

		public static string Bold(string s, Target? t)
		{
			if (!t.HasValue)
				t = Target.Html;
			if (t == Target.Html)
				return "<b>" + s + "</b>";
			return s;
		}
		public static string Bold(string s) { return Bold(s, Target.Html);}


		public static string XmlToHtml(string s)
		{
			if (s == null)
				return null;
			var h = new StringBuilder(s);
			h.Replace("<", "&lt;");
			h.Replace(">", "&gt;");
			return h.ToString();
		}
    }
}
