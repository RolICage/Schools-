function ObjectControl(id, DataMethodType, DataMethodName)
{
	this.Properties=null;
	this.Mode='View';
	this.NoData='No Data.';
	this.Action='None';

	var Title=el(id+'_Title');
	var Content=el(id+'_Content');
	var EditButton=el(id+'_EditButton');
	var SaveButton=el(id+'_SaveButton');
	var SaveSpan=el(id+'_SaveSpan');
	var o=this;

	this.GetData=function()
	{
		if(!DataMethodType||!DataMethodName)
			return;
		this.SetTitle('');
		ShowLoading(Content);
		var request=new Object();
		request.DataMethodType=DataMethodType;
		request.DataMethodName=DataMethodName;
		var oi=new Object();
		oi.Action=this.Action;
		oi.Parameters=this.Parameters;
		oi.Properties=this.Properties;
		if(oi.Properties)
		{
			for(var i=0;i<oi.Properties.length;i++)
				oi.Properties[i].Control=null;
			for(var i=0;i<oi.Properties.length;i++)
				oi.Properties[i].Validator=null;
		}
		request.ObjectInfo=oi;
		Web.Ajax.Controls.Object.GetData(request, this.SetData);
	}
	this.SetData=function(r)
	{
		o.Properties=r.Properties;
		if(r.OnComplete)
			eval(r.OnComplete);
		o.Render(r.Message);
		o.SetTitle(r.Title);
		o.Action='None';
	} 
	this.SetTitle=function(t)
	{
		Title.innerHTML=t;
	}
	this.GetValueSpan=function(p)
	{
		if(p.ColSpan>1)
		{
			return (p.ColSpan*2)-1;
		}
		return 1;
	}
	this.GetInputId=function(p)
	{
		return id+p.Binding;
	}
	this.GetValidatorId=function(p)
	{
		return id+p.Binding+'Val';
	}
	this.RenderPropertyValue=function(p)
	{
		var Width='';
		if(p.TextBoxWidth)
			Width='width:'+p.TextBoxWidth+';';
		if(this.Mode=='Edit'&&!p.ReadOnly&&p.Type)
		{
			var html='';
			var id=this.GetInputId(p);
			var idhtml='id="'+id+'"';
			if(p.Type=='text')
			{
				html+='<input '+idhtml+' style="'+Width+'" type="text" value="'+nonull(p.Value)+'" />';                
			}
			if(p.Type=='checkbox')
			{
				var on=(p.Value!=null&&p.Value.toLower()=='true');
				html+='<input '+idhtml+' type="checkbox" "'+(on?'checked':'')+'" />';
			}
			if(p.Type=='select')
			{
				html+='<select '+idhtml+' style="'+Width+'">';
				html+='<option value="">Select...</option>';
				if(p.Options)
				{
					for(var i=0;i<p.Options.length;i++)
					{
						var Selected=(p.Value==p.Options[i].Value?'selected':'');
						html+='<option '+Selected+' value="'+nonull(p.Options[i].Value)+'">'+p.Options[i].Text+'</option>';
					}
				}
				html+='</select>';
			}
			if(p.Type=='Calendar')
			{
				var cid=id+p.Binding;
				var c=new Calendar(cid,0,0,'b');
				c.Date=p.Value;
				c.Required=p.Required;
				p.Control=c;
				p.Validator=p.Control;
				window[cid]=c;
				html+=p.Control.GetClientHtml(Width);
				return html;
			}
			var ValId=this.GetValidatorId(p);
			p.Validator=new Validator(ValId);
			p.Validator.SourceId=id;
			p.Validator.Required=p.Required;
			p.Validator.RegEx=p.RegEx;
			p.Validator.Message=p.Message; 
			html+='&nbsp;'+p.Validator.GetClientHtml();
			return html;
		}
		//Non Edit
		if(p.OnRender)
		{
			return window[p.OnRender](p.Value);
		}
		if(p.Type=='Calendar')
		{
			return new Calendar().GetFormatString(p.Value);
		}
		if(!p.Value)
			return '&nbsp;';
		if(p.Value.constructor == Array)
		{
			var s='';
			for(var i=0;i<p.Value.length;i++)
			{
				if(i>0) 
					s+=', ';
				s+=p.Value[i];
			}
			return s;
		}
		return nonull(p.Value);
	}
	this.RenderProperty=function(p, ValueSpan)
	{
		var html='';
		var vs='';
		if(ValueSpan!=null&&ValueSpan>1)
			vs='colspan="'+ValueSpan+'"';
		html+='<td class="PropertyTitle">'+(p.Title?p.Title:'&nbsp;')+'</td>';
		html+='<td class="PropertyValue" '+vs+'>'+this.RenderPropertyValue(p)+'</td>';
		return html;
	}
	this.RenderTable=function(d)
	{
		var html='';
		html+='<table cellspacing="0" class="ObjectTable">';
		var c=this.Columns;
		var colcount=0;
		var startrow=true;
		var endrow=false;
		for(var i=0;i<d.length;i++)
		{
			var p=d[i];
			if(!p.Visible)
				continue;
			if(startrow)
			{
				html+='<tr>';
				startrow=false;
			}
			var ValueSpan=this.GetValueSpan(p);
			html+=this.RenderProperty(p, ValueSpan);
			colcount+=ValueSpan;
			if(colcount>=c)
				endrow=true;
			var colsleft=c-colcount;
			if(i==d.length-1)
			{
				for(var j=0;j<colsleft;j++)
					html+=this.RenderProperty({Title:null,Value:null});
				endrow=true;
			}
			if(endrow)
			{
				html+='</tr>';
				colcount=0;
				startrow=true;
				endrow=false;
			}
		}
		html+='</table>';
		return html;
	}
	this.Render=function(m)
	{
		var d=this.Properties;
		var html='';
		if(m)
			html='<div class="Error">'+m+'</div>'
		else
		{
			if(!d||d.length==0)
				html='<div class="NoData">'+this.NoData+'</div>';
			else
			{
				html=this.RenderTable(d);
			}
		}
		Content.innerHTML=html;
		if(d)
		{
			for(var i=0;i<d.length;i++)
			{
				var p=d[i];
				if(p.Control&&p.Control.Init)
					p.Control.Init();
				if(p.Validator&&p.Validator.Init)
					p.Validator.Init();
			}
		}
	}
	this.SwitchMode=function(m)
	{
		if(this.Mode==m)
			return;
		if(this.Mode=='View')
		{
			this.Mode='Edit';
			EditButton.value='Cancel';
			SaveSpan.style.display='inline';
		}
		else
		{
			this.Mode='View';
			EditButton.value='Edit';
			SaveSpan.style.display='none';
		}
		this.Render();
	}
	this.IsValid=function()
	{
		var valid=true;
		if(!this.Properties)
			return valid;
		for(var i=0;i<this.Properties.length;i++)
		{
			var p=this.Properties[i];
			var v=p.Validator;
			if(v)
			{
				valid=v.IsValid()&&valid;
				p.NewValue=v.GetAnswer();
			}
		}
		return valid;
	}
}
ObjectControl.prototype=new AjaxControl();
