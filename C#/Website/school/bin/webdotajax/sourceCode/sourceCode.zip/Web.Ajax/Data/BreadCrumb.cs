using System;
using System.Collections.Generic;
using System.Text;

namespace Web.Ajax.Data
{
    public class BreadCrumb
    {
        public string Url;
        public string QueryString;
        public string Title;

        public string Render()
        {
            return "";

        }
    }
}
