﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;

namespace Web.Ajax.Controls
{
    [ToolboxData("<{0}:Dashboard runat=\"server\"></{0}:Dashboard>")]
    [ParseChildren(false)]
    public class Dashboard : AjaxControl
    {
        protected override void OnInit(EventArgs e)
        {
            if (Page != null&&this.Visible)
            {
                Page.RegisterJavascriptFile(Resources.Javascript.Dashboard);
                Page.RegisterStyleSheet(Resources.StyleSheets.Dashboard);
            }
        }

        private int maxCols=3;
        public int MaxCols
        {
            get { return maxCols; }
            set { maxCols = value; }
        }

        private DashboardPanel[] panels;
        public DashboardPanel[] Panels
        {
            get 
            {
                if (panels == null)
                {
                    List<DashboardPanel> list = new List<DashboardPanel>();
                    foreach (Control c in this.Controls)
                    {
                        if (c is DashboardPanel)
                            list.Add((DashboardPanel)c);
                    }
                    panels = list.ToArray();
                }
                return panels; 
            }
            set { panels = value; }
        }

        protected override void Render(System.Web.UI.HtmlTextWriter writer)
        {
            if (!Visible)
                return;
            var html= @"
            <div id=""#id#"">
                <div id=""#id#_content""></div>
                <div id=""#id#_windowbar"" style=""position:absolute;""></div>
            </div>";
            html = html.Replace("#id#",JavascriptId);


            var script = @"
            <script type=""text/javascript"">
            var #id#=new DashBoard('#id#');";
            foreach (DashboardPanel p in Panels)
            {
                //html+=p.GetHtml();
                script+=p.GetScript(JavascriptId);
            }
            script += @"#id#.Init();
            </script>";
            script = script.Replace("#id#", JavascriptId);


            writer.WriteLine(html);
            base.Render(writer);
            writer.WriteLine(script);
        }

        public override void RenderBeginTag(HtmlTextWriter writer) { }
        public override void RenderEndTag(HtmlTextWriter writer) { }
    }

    [ToolboxData("<{0}:DashboardPanel runat=\"server\"></{0}:DashboardPanel>")]
    [ControlBuilderAttribute(typeof(ControlBuilder))]
    [ParseChildren(false)]
    public class DashboardPanel : CompositeControl
    {
        private bool minimised=true;
        public bool Minimised
        {
            get{return minimised;}
            set{minimised=value;}
        }

        private bool scrollable = false;
        public bool Scrollable
        {
            get { return scrollable; }
            set { scrollable = value; }
        }

        private bool userVisible = true;
        public bool UserVisible
        {
            get { return userVisible; }
            set { userVisible = value; }
        }


        private string title;
        public string Title
        {
            get { return title; }
            set { title = value; }
        }

        private string javascriptId;
        public string JavascriptId
        {
            get { return javascriptId; }
            set { javascriptId = value; }
        }

        private string onLoad;
        public string OnLoad
        {
            get { return onLoad; }
            set { onLoad = value; }
        }

        private int colSpan=1;
        public int ColSpan
        {
            get { return colSpan; }
            set { colSpan = value; }
        }

        protected override void Render(System.Web.UI.HtmlTextWriter writer)
        {
            if (!Visible)
                return;
            var html=@"
            <div id=""#id#"" class=""DashboardPanel"">
                <div id=""#id#_head"" class=""PanelHeading"">
                    <div id=""#id#_opts"" class=""Options""></div>
                    "+this.Title+@"
                </div>
                <div id=""#id#_con"" class=""Content"+(Scrollable?" Scrollable":"")+@""">";
            html=html.Replace("#id#",JavascriptId);
            writer.WriteLine(html);
            base.Render(writer);
            writer.WriteLine(@"
                </div>
            </div>");
        }

        public string GetScript(string DashId)
        {
            if (!Visible)
                return "";
            var script = @"
            var #id#=new Panel('#id#',#did#);
            #id#.Minimised=" + Json.ConvertToJson(this.Minimised) + @";
            #id#.Visible=" + Json.ConvertToJson(this.UserVisible) + @";
            #id#.OnLoad=" + Json.ConvertToJson(this.OnLoad) + @"
            #id#.Colspan=" + Json.ConvertToJson(this.ColSpan) + @"
            #did#.AddPanel(#id#);";
            script = script.Replace("#id#", JavascriptId);
            script = script.Replace("#did#", DashId);
            return script;
        }

        public override void RenderBeginTag(HtmlTextWriter writer){}
        public override void RenderEndTag(HtmlTextWriter writer){}
    }

    public class DashboardPanelConfig
    {
        public string Id;
        public bool Visible;
        public string Description = "?";
        public int[] Rights;
        public DashboardSetting DefaultSetting = new DashboardSetting();

        public static DashboardPanelConfig[] Get()
        {
            string file=HttpContext.Current.Server.MapPath("~/Configuration/Dashboard.json");
            if (!File.Exists(file))
                throw new Exception("Unable to read Dashboard config file: "+file);
            return (DashboardPanelConfig[])Json.Load(file, typeof(DashboardPanelConfig[]));
        }

        public static DashboardPanelConfig Get(DashboardPanelConfig[] list,string Id)
        {
            if (list == null)
                return null;
            foreach(DashboardPanelConfig c in list)
                if (c.Id == Id)
                    return c;
            return null;
        }
    }

    public class DashboardSetting
    {
        public string Id;
        public bool Visible;
        public bool Minimised=true;
        public int Colspan = 1;

        public static DashboardSetting Get(DashboardSetting[] list,string id)
        {
            if (list == null)
                return null;
            foreach (DashboardSetting s in list)
                if (s.Id == id)
                    return s;
            return null;
        }
    }
}
