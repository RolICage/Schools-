using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Web.Ajax.Controls
{
	[ToolboxData("<TabHeadingRight><TabHeadingRight>")]
	[ControlBuilderAttribute(typeof(ControlBuilder))]
	[ParseChildren(false)] 
	public class TabHeadingRight : CompositeControl
	{
		private bool Rendered = false;

		protected override void Render(HtmlTextWriter writer)
		{
			if (Rendered)
				return;
			Rendered = true;
			base.Render(writer);
		}

		public void RenderHtml(HtmlTextWriter writer)
		{
			Render(writer);
		}

		public override void RenderBeginTag(HtmlTextWriter writer)
		{

		}

		public override void RenderEndTag(HtmlTextWriter writer)
		{

		}
	}
}
