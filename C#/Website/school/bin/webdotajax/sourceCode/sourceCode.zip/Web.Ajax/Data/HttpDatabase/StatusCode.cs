﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;

namespace Web.Ajax.Data.HttpDatabase
{
	public class StatusCode
	{
		public const int OK = 200;			//The request has succeeded.
		public const int Created=201;		//A new Resource Has been created.
		public const int Accepted = 202;	//The request has been accepted for processing, but the processing has not been completed

		public const int UnAuthorized = 401;				//The client does not have permission for this Method on this Resource.
		public const int NotFound = 404;					//The resource was not found.
		public const int MethodNotAllowed = 405;			//The request method is not allowed.


		public static void Set(int Status, HttpContext c, bool ClearResponse)
		{
			if (ClearResponse)
				c.Response.Clear();
			c.Response.StatusCode = Status;
		}

		public static void Set(int Status, HttpContext c)
		{
			Set(Status, c);
		}
	}
}
