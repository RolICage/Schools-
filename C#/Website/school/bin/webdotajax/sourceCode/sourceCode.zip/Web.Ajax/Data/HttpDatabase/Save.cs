﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Collections;

namespace Web.Ajax.Data.HttpDatabase
{
	public class Save : RequestMethod
	{
		public Save()
		{
			EnsureCollection = true;
		}

		public override void ProcessMethod()
		{
			if (Path.IsResource)
			{
				var o = (Hashtable)GetRequestObject();
				Collection.CheckConstraints(o);
				FileSystem.SaveFile(Path.PhysicalPath, GetRequestData());
				Collection.EnsureIndexes();
			}
			else
			{
				if (Path.IsCollection)
				{
					var o = GetRequestObject();
				}
				//Check for Collection Folder
				//If None Exists create collection Folder
				//Get next id in collection folder
				//Save file with new ID.
			}
			//Collection.
		}
	}
}
