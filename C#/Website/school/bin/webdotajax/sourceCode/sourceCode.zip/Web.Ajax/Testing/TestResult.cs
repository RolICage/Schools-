﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Web.Ajax.Testing
{
	public class TestResult
	{
		public bool Result=true;
		public string Message;
		public string[] Script;

		public delegate TestResult GetDelegate();

		public TestResult()
		{

		}

		public TestResult(string message)
		{
			Message = message;
		}

		public static TestResult Get(GetDelegate d)
		{
			var r = new TestResult();
			try
			{
				return d();
			}
			catch (Exception e)
			{
				r.Message = e.Message;
				r.Result = false;
			}
			return r;
		}
	}
}
