function PopupMenu(id, x, y, s)
{
	if(!x) x=0;if(!y) y=0;
	var m=el(id);var so;
	this.DataMethodType=null;
	this.DataMethodName=null;
	this.NoData='No Data.';
	this.Data=null;
	this.ShowEvent='Hover';
	this.HideEvent='MouseOut';
	this.Visible=false;
	var This=this;
	this.Panel=el(id);
	var Content=null;
	this.SetPos=function(x,y)
	{
		if(x!=null)
			m.style.left=x+'px';
		if(y!=null)
			m.style.top=y+'px';
	}
	this.RePosition = function() {
		var dx = x;
		var dy = y;
		if (so) {
			var p = GetPosition(so, s);
			if (p) {
				dx += p.x;
				dy += p.y;
			}
		}
		this.SetPos(0, 0);
		m.style.display = 'block';

		if (s.indexOf('r') > -1 && s.indexOf('r+') == -1)
			dx -= m.offsetWidth;
		if (s.indexOf('c') > -1)
			dx -= m.offsetWidth / 2;
		if (s.indexOf('m') > -1)
			dx -= m.offsetHeight / 2;
		var ms = GetSize(m);
		var ds = GetDocSize();
		if ((dx + ms.w) > ds.w)
			dx = (ds.w - ms.w);
		if ((dy + ms.h) > ds.h) {
			if (dy > ds.h)	//doc height can be wrong if a popup element changes the height of the page
				dy = dy - ms.h;
			else
				dy = (ds.h - ms.h);
		}
		this.SetPos(dx, dy);

		if (Web.Ajax.Browser == 'IE6') {
			var f = el(id + 'IE6Frame');
			if (f) {
				f.style.width = ms.w + 'px';
				f.style.height = ms.h + 'px';
			}
		}
	}
	this.Show = function(o) {
		if (m == null)
			m = el(id);
		if (this.Visible)
		{
			if ((this.HideEvent == 'Click') && (this.ShowEvent == 'Click'))
				this.Hide();
			return;
		}
		so = o;
		this.RePosition();
		this.Visible = true;
		if (this.DataMethodName && !this.SuppressAjax)
			this.GetData();
	}
	this.ShowFromNewSource = function(o, html) {
		if (m == null)
			m = el(id);
		if (this.HideEvent == 'MouseOut') {
			o.onmouseout = function(event) { This.OnMouseOut(event, o) };
			if (!m.onmouseout)
				m.onmouseout = function(event) { This.OnMouseOut(event, o) };
		}
		if (html) {
			if (Web.Ajax.Browser == 'IE6') {
				html = '<iframe id="' + id + 'IE6Frame" src="resource.axd?Null" class="PopupIE6Background" frameborder="0" scrolling="no"></iframe>' + html;
			}
			this.Panel.innerHTML = html;
		}
		this.Source = o;
		this.Show(o);
	}
	this.SetParent = function(p)
	{
		this.Parent = p;
		if (p)
			p.AddChild(this);
	}
	this.AddChild=function(c)
	{
		if(!c)
			return;
		var cl=this.Children;
		if(!cl)
			cl=[];
		for(var i=0;i<cl.length;i++)
		{
			if(cl[i]==c)
				return;
		}
		cl[cl.length]=c;
		this.Children=cl;
	}
	this.DestInChild=function(dest)
	{
		if(!this.Children)
			return false;
		for(var i=0;i<this.Children.length;i++)
		{
			if(ElementIn(dest, this.Children[i].Panel))
				return true;
		}
		return false;
	}
	this.OnMouseOut = function(e, o) {
		if (!e)
			e = window.event;
		var src = (window.event) ? e.srcElement : e.target;
		var dest = (e.relatedTarget) ? e.relatedTarget : e.toElement;
		var hide = false;
		var LeavingSource = ElementIn(src, so);
		var DestInSource = ElementIn(dest, so);
		//var DestInMenu = ElementInElementWithClass(dest, 'PopupMenu');
		var DestInParent = this.Parent ? ElementIn(dest, this.Parent.Panel) : false;
		var dic = this.DestInChild(dest);
		try {
			var LeavingMenu = ElementIn(src, m);
			var EnteringMenu = ElementIn(dest, m);
			if (LeavingMenu && !EnteringMenu && !DestInSource && !DestInParent && !dic)
				hide = true;
			if (LeavingSource && !EnteringMenu && !DestInSource)
				hide = true;
		}
		catch (e) {
			hide = true;
		}
		if (hide) {
			this.Hide();
			if (!DestInParent && this.Parent != null)
				if (LeavingMenu)
					this.Parent.HideChain();
				else
					this.Parent.Hide();
		}
	}
	this.Hide=function(e,o)
	{
		if(m!=null)
			m.style.display='none';
		this.Visible=false;
	}
	this.HideChain = function() {
		this.Hide();
		if (this.Parent)
			this.Parent.Hide();
	}
	this.GetData = function() {
		this.Panel.innerHTML = '<div class="PopupMenu" id="' + id + '_Content"><div class="MenuItemLoading">&nbsp;</div></div>';
		this.RePosition();
		var request = new Object();
		request.DataMethodType = this.DataMethodType;
		request.DataMethodName = this.DataMethodName;
		var pi = new Object();
		pi.Parameters = this.Parameters;
		request.PopupMenuInfo = pi;
		Web.Ajax.Controls.PopupMenu.GetData(request, this.SetData);
	}
	this.SetData=function(r)
	{
		This.Data=r.Data;
		This.Render(r.Message);
	}
	this.RenderItem=function(item)
	{
		var html='';
		html+='<div class="MenuItem" ';
		if(item.OnClick)
			html+='onclick="'+item.OnClick+'" ';
		html+='>';
		if(item.Image)
			html+='<img src="'+ResourceUrl(item.Image)+'" class="MenuItemImage" />'
		html+=item.Text;
		html+='</div>';
		return html;
	}
	this.RenderItems=function(d)
	{
		var html='';
		if(d.MenuItems)
		{
			for(var i=0;i<d.MenuItems.length;i++)
				html+=this.RenderItem(d.MenuItems[i]);
		}
		else
			html='<div class="PopupMenuNoData">'+this.NoData+'</div>';
		return html;
	}
	this.Render = function(m) {
		var d = this.Data;
		var html = '';
		if (m)
			html = '<div class="PopupMenuError">' + m + '</div>';
		else {
			if (!d || d.length == 0)
				html = '<div class="PopupMenuNoData">' + this.NoData + '</div>';
			else {
				html = d.Html;
				if (!html)
					html = this.RenderItems(d);
			}
		}
		//*
		This.Visible = false;
		This.SuppressAjax = true;
		html = '<div class="PopupMenu">' + html + '</div>';
		This.ShowFromNewSource(This.Source, html);
		This.SuppressAjax = false;
		/*/
		Content.innerHTML = html;
		This.RePosition();
		//*/
	}
}
PopupMenu.prototype=new AjaxControl();