﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Web.Ajax.Testing
{
	public class Test : Attribute, IComparable
	{
		public string Name;
		public string[] Script;
		public int Order = int.MaxValue;

		public int CompareTo(object o)
		{
			var t = (Test)o;
			if (t == null)
				return -1;
			return Order.CompareTo(t.Order);
		}
	}
}
