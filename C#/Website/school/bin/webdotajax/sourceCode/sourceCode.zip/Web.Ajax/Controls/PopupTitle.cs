using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace Web.Ajax.Controls
{
	/// <summary>
	/// Represents a Title Bar in a Html Popup. Can contain a Left, Middle and a Right part control.
	/// The Title gets rendered as a table row and should be contained within a Popup control.
	/// 
	/// The Rendered Html will look something like this:
	///	<tr>
	///		<td class="PopupTitleLeft" style="width:33%;">Left Title Content</td>	
	///		<td class="PopupTitleMiddle" style="width:33%;">Middle Title Content</td>	
	///		<td class="PopupTitleRight" style="width:33%;">
	///			<table cellpadding="0" cellspacing="0" style="width:100%;">
	///				<tr>
	///					<td>Right Title Content</td>
	///					<td style="padding-left:3px;"><img alt="Close" src="/AdminTool/Images/Close.png" title="Close" onclick="PopupID.Hide();" /></td>
	///				</tr>
	///			</table>
	///		</td>	
	///	</tr>
	/// </summary>
	[ToolboxData(@"<{0}:PopupTitle runat=""server"" Text=""Title""></{0}:PopupTitle>")]
	[ControlBuilderAttribute(typeof(PopupTitleBuilder))]
	[ParseChildren(false)] 	
	public class PopupTitle : CompositeControl
	{
		#region Constructor
		/// <summary>
		/// Constructor
		/// </summary>
		public PopupTitle()
		{
			CssClass = "PopupTitle";
			ID = "Title";
		} 
		#endregion

		#region Rendered
		/// <summary>
		/// Indicates if the control has already been rendered in this life cycle. 
		/// </summary>
		public bool Rendered = false; 
		#endregion

		#region PartCount
		/// <summary>
		/// The Number of Title Parts. Will range from 0 to 3 if Left, Middle or Right tags are present. 
		/// </summary>
		public int PartCount = 0; 
		#endregion

		#region LoadTitles
		private bool TitlesLoaded=false;
		/// <summary>
		/// Searches the Control collection for the TitleLeft, TitleMiddle and TitleRight.
		/// </summary>
		private void LoadTitles()
		{
			if(TitlesLoaded)
				return;
			for (int i = 0; i < Controls.Count; i++)
			{
				if (Controls[i] is PopupTitleLeft)
				{
					titleLeft = (Controls[i] as PopupTitleLeft);
					PartCount++;
				}
				if (Controls[i] is PopupTitleMiddle)
				{
					titleMiddle = (Controls[i] as PopupTitleMiddle);
					PartCount++;
				}
				if (Controls[i] is PopupTitleRight)
				{
					titleRight = (Controls[i] as PopupTitleRight);
					PartCount++;
				}
			}
			TitlesLoaded = true;
		} 
		#endregion

		#region TitleLeft
		private PopupTitleLeft titleLeft = null;
		public PopupTitleLeft TitleLeft
		{
			get
			{
				LoadTitles();
				return titleLeft;
			}
		} 
		#endregion

		#region TitleMiddle
		private PopupTitleMiddle titleMiddle = null;
		public PopupTitleMiddle TitleMiddle
		{
			get
			{
				LoadTitles();
				return titleMiddle;
			}
		}
		#endregion

		#region TitleRight
		private PopupTitleRight titleRight = null;
		public PopupTitleRight TitleRight
		{
			get
			{
				LoadTitles();
				return titleRight;
			}
		}
		#endregion
		
		#region Render
		/// <summary>
		/// Renders the PopupTitle Control. Will render a PopupTitleLeft, PopupTitleMiddle and PopupTitleRight Control if it 
		/// can find them in its control collection.
		/// </summary>
		/// <param name="writer"></param>
		public void Render(HtmlTextWriter writer, string PopupId)
		{
			if (Rendered)
				return;
			PopupTitleLeft pl = TitleLeft;
			PopupTitleMiddle pm = TitleMiddle;
			PopupTitleRight pr = TitleRight;
			if (PartCount == 0)
				return;
			writer.Write("<tr id=\""+PopupId+"_Title\" ><td class=\"PopupTopLeft\"></td>");
			string width = "width:33%;";
			if (PartCount != 3)
				width = "";
			if (pl != null)
			{
				pl.Width = width;
				pl.PopupJavascriptId = PopupId;
				pl.Render(writer);
			}
			if (pm != null)
			{
				pm.Width = width;
				pm.Render(writer);
			} 
			if (pr != null)
			{
				pr.Width = width;
				pr.Render(writer);
			}
            writer.Write("<td class=\"PopupTopRight\"></td></tr>");
			Rendered = true;
		} 
		#endregion	

		#region Disabled Base methods - (to prevent double rendering).
		/// <summary>
		/// Overridden to disable base behaviour
		/// </summary>
		/// <param name="writer"></param>
		protected override void RenderContents(HtmlTextWriter writer)
		{
		}

		/// <summary>
		/// Overridden to disable base behaviour
		/// </summary>
		/// <param name="writer"></param>
		public override void RenderControl(HtmlTextWriter writer)
		{
		}

		/// <summary>
		/// Overridden to disable base behaviour
		/// </summary>
		/// <param name="writer"></param>
		protected override void RenderChildren(HtmlTextWriter writer)
		{
		}

		/// <summary>
		/// Overridden to disable base behaviour
		/// </summary>
		/// <param name="writer"></param>
		public override void RenderBeginTag(HtmlTextWriter writer)
		{
		}

		/// <summary>
		/// Overridden to disable base behaviour
		/// </summary>
		/// <param name="writer"></param>
		public override void RenderEndTag(HtmlTextWriter writer)
		{
		} 
		#endregion
	}

	#region PopupTitleBuilder
	/// <summary>
	/// The Control Builder for the PopupTitle Control.
	/// </summary>
	internal class PopupTitleBuilder : ControlBuilder
	{
		public override Type GetChildControlType(string tagName, System.Collections.IDictionary attribs)
		{
			if (tagName.ToLower() == "left")
				return typeof(PopupTitleLeft);
			if (tagName.ToLower() == "middle")
				return typeof(PopupTitleMiddle);
			if (tagName.ToLower() == "right")
				return typeof(PopupTitleRight);
			return null;
		}
	}
	#endregion
}
