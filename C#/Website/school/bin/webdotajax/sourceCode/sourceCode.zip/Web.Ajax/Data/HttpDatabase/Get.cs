﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace Web.Ajax.Data.HttpDatabase
{
	public class Get : RequestMethod
	{
		public override void ProcessMethod()
		{
			if (Path.IsResource)
			{
				//return the resource identified
				Response.Clear();
				Response.Write(FileSystem.GetFileContent(Path.PhysicalPath));
			}
			else
			{
				if (Path.IsCollection)
				{
					//Collection.Get(Request);
				}
				else
				{
					StatusCode.Set(StatusCode.NotFound, HttpContext);
				}
			}
		}
	}
}
