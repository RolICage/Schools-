using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace Web.Ajax.Controls
{
	/// <summary>
	/// Represents the Right part of a Popup Title. It gets rendered as a table cell and should be contained within 
	/// a PopupTitle Control.
	/// </summary>
	[ToolboxData("<{0}:PopupTitleRight runat=\"server\"></{0}:PopupTitleRight>")]
	[ControlBuilderAttribute(typeof(ControlBuilder))]
	[ParseChildren(false)] 
	public class PopupTitleRight : PopupTitlePart
	{
		#region Constructor
		/// <summary>
		/// Constructor
		/// </summary>
		public PopupTitleRight()
		{
			CssClass = "PopupTitleRight";
			ID = "Right";
		} 
		#endregion

		public bool DisplayClose = true;

		public override void RenderBeginTag(HtmlTextWriter writer)
		{
			base.RenderBeginTag(writer);
			writer.Write("<table cellpadding=\"0\" cellspacing=\"0\" style=\"width:100%;vertical-align:top;\"><tr><td>");
		}

		public string Type;

		public override void RenderEndTag(HtmlTextWriter writer)
		{
			var renderMax = true;

            var url = Resources.ImageUrl(Resources.Images.Close);
            var hurl = Resources.ImageUrl("CloseHover.gif");
			if (!string.IsNullOrEmpty(Type) && Type.Contains("Note"))
			{
				hurl = url = Resources.ImageUrl("X.gif");
				renderMax = false;
			}


			var murl = Resources.ImageUrl("Max.gif");
			var mhurl = Resources.ImageUrl("MaxHover.gif");



			if (DisplayClose)
			{
				string PopupId = "";
				IJavascriptControl ij = (IJavascriptControl)Parent.Parent;
				if (ij != null)
					PopupId = ij.JavascriptId;
                writer.Write("</td><td style=\"padding-left:3px;text-align:right;\">");
				if(renderMax)
					writer.Write("<img class=\"PopupCloseIcon\" id=\""+PopupId+".Max\" style=\"display:none;\" alt=\"Maximize\" src=\"" + murl + "\" title=\"Maximize\" onmouseover=\"this.src='" + mhurl + "'\" onmouseout=\"this.src='" + murl + "'\" onclick=\"" + PopupId + ".Maximize();\" />");
				writer.Write("<img class=\"PopupCloseIcon\" alt=\"Close\" src=\"" + url + "\" title=\"Close\" onmouseover=\"this.src='" + hurl + "'\" onmouseout=\"this.src='" + url + "'\" onclick=\"" + PopupId + ".Close();\" />");
			}
			writer.Write("</td></tr></table>");
			base.RenderEndTag(writer);
		}
	}
}
