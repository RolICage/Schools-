function LazyLoading(id, DataMethodType, DataMethodName)
{
	var Content=el(id);
	var o=this;
	this.Data=null;
	this.NoData='No Data.';
	this.GetData=function()
	{
		ShowLoading(Content);
		var request=new Object();
		request.DataMethodType=DataMethodType;
		request.DataMethodName=DataMethodName;
		var li=new Object();
		li.Parameters=this.Parameters;
		request.LazyLoadingInfo=li;
		Web.Ajax.Controls.LazyLoadingControl.GetData(request, this.SetData);
	}
	this.SetData=function(r)
	{
		o.Data = r.Data;
		o.Render(r.Message);
		if (r.OnComplete)
			eval(r.OnComplete);
	}
	this.Render=function(m)
	{
		var d=this.Data;
		var html='';
		if(m)
			html='<div class="Error">'+m+'</div>'
		else
		{
			if(!d||d.length==0)
				html='<div class="NoData">'+this.NoData+'</div>';
			else
				html+=d;
		}
		Content.innerHTML=html;
	}
	this.Clear=function()
	{
		this.Data=null;
		this.Render();
	}
	var t = this;
	$(window).load(function() {
		t.GetData();
	})
}
LazyLoading.prototype=new AjaxControl();

