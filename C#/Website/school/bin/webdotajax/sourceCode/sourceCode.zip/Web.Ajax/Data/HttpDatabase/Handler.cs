﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Routing;

namespace Web.Ajax.Data.HttpDatabase
{
	public class Handler : IHttpHandler, IRouteHandler
	{
		public void ProcessRequest(HttpContext c)
		{
			var rm = RequestMethod.Create(c);
			if (rm != null)
			{
				rm.ProcessRequest();
			}


			var req = c.Request;
			var m = req.RequestType;
			var p = c.Request.Path;
			if (p.StartsWith(c.Request.ApplicationPath))
				p = p.Substring(c.Request.ApplicationPath.Length + 1);
			c.Response.Write("Path: " + p);
			c.Response.Write("<br>");
			c.Response.Write("Method: " + m);
		}

		public bool IsReusable
		{
			get
			{
				return false;
			}
		}

		public IHttpHandler GetHttpHandler(RequestContext c)
		{
			return this;
		}
	}
}
