﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Web.Ajax.InversionOfControl
{
	public interface IContainer
	{
		void Map<IT, T>() where T : IT;

		object GetImplementation(Type t);

		I GetImplementation<I>();

	}
}
