﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace Web.Ajax.Data.HttpDatabase
{
	public class Constraint
	{
		public static Constraint[] Get(string CollectionPhysicalPath)
		{
			return new Constraint[]{};
		}


		public bool Check(Hashtable o)
		{
			return true;
		}
	}
}
