﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace Web.Ajax.Data.HttpDatabase
{
	public class Delete : RequestMethod
	{
		public override void ProcessMethod()
		{
			if (Path.IsResource)
			{
				//FileSystem.
				//delete the resource identified
			}
			else
			{
				//Check for Collection Folder
				//If None Exists do nothing
				//Else delete filtered collection
			}
		}
	}
}
