function Popup(id)
{
	this.ExcessHeight = 43;	//Height of PopupTopLeft + PopupBottomLeft change if these changing
	this.Id=id;
	this.Visible=false;
	this.MaxContentWidth=0;
	var b=el('Modal_Background');
	var c = el(id + '_Content');
	if (c == null)
		c = el(id);
	var ic=el(id+'_InnerContent');
	var table=el(id+'_Table');
	var h;
	var de=document.documentElement;
	var o=this;
	this.Modal=true;
	this.Maximised=false;
	this.OnHide=null;
	this.Position='cm';
	this.Offset = { x: 0, y: 0 };
	this.CanMax = false;
	this.MaxIconId = id + '.Max';
	this.MaxIcon = el(this.MaxIconId);
	this.SetSize = function(w, h) {
		if (table && ic) {
			table.style.width = w + 'px';
			table.style.height = h + 'px';
			ic.style.height = h - 20 + 'px'
		}
		else 
		{
			c.style.width = w + 'px';
			c.style.height = h + 'px';
		}
	}
	this.ReCenter = function()
	{
		c.style.left = '0px';
		c.style.top = '0px';
		var ds = GetDocSize();
		b.style.height = ds.h + 'px';
		b.style.width = ds.w + 'px';
		var l, t, h, w;
		var st = de.scrollTop;
		var sl = de.scrollLeft;
		var ch = de.clientHeight;
		var cw = de.clientWidth;
		if (c.offsetWidth > this.MaxContentWidth)
			this.MaxContentWidth = c.offsetWidth;
		if (this.PositionSource)
		{
			this.SetRelativePosition(this.PositionSource, this.SourceSide);
			return;
		}
		if (this.Maximised)
		{
			l = 20 + sl;
			t = 20 + st;
			w = cw - 40;
			h = ch - 40 - this.ExcessHeight;
			this.SetSize(w, h);
		}
		else
		{
			if (this.Position.indexOf('r') != -1)
				l = (cw) - (this.MaxContentWidth) + sl + this.Offset.x;
			else if (this.Position.indexOf('l') != -1)
				l = this.Offset.x + sl;
			else
				l = ((cw / 2) - (this.MaxContentWidth / 2) + sl);

			if (this.Position.indexOf('t') != -1)
				t = this.Offset.y + st;
			else if (this.Position.indexOf('b') != -1)
				t = ch - c.offsetHeight + st + this.Offset.y;
			else
				t = ((ch / 2) - (c.offsetHeight / 2) + st);
		}
		if (l < 0) l = 0;
		if (t < 0) t = 0;
		c.style.left = l + 'px';
		c.style.top = t + 'px';
	}
	this.SetRelativePosition = function(o, s)
	{
		var l = 0;
		var t = 0;
		if (o)
		{
			var p = GetPosition(o, s);
			if (p)
			{
				l += p.x;
				t += p.y;
			}
		}
		l -= this.MaxContentWidth;
		if (l < 0) l = 0;
		if (t < 0) t = 0;
		c.style.left = (l+(this.LeftOffset?this.LeftOffset:0)) + 'px';
		c.style.top = (t+(this.TopOffset?this.TopOffset:0)) + 'px';
	}
	this.ShowPage = function(url, title, width, height, onhide, canmax) {
		this.CanMax = canmax;
		if (this.MaxIcon) {
			if (canmax)
				this.MaxIcon.style.display='';
			else
				this.MaxIcon.style.display = 'none';
		}
		this.OnHide = onhide;
		this.MaxContentWidth = 0;
		if (title)
			this.SetTitle(title);
		if (width)
			table.style.width = width + 'px';
		if (height)
			table.style.height = height + 'px';
		var style = 'width:100%;height:100%;';
		var html = '<iframe frameborder="0" src="' + url + '" style="' + style + '" id="'+id+'IFrame" horizontalscrolling="no" />';
		if (Web.Ajax.Browser == 'FireFox')
			ic.style.height = '100%';
		else	// for 100% height bug in IE
			ic.style.height = height ? ((height - this.ExcessHeight) + 'px') : '100%';
		ic.innerHTML = html;
		this.Show();
	}
	this.Resize = function() {
		if (!this.Modal && Web.Ajax.Browser == 'IE6') {
			var f = el(id + 'Frame');
			if (f) {
				var cs = GetSize(c);
				f.style.width = cs.w + 'px';
				f.style.height = cs.h + 'px';
			}
		}
	}
	this.Show = function(src, side) {
		this.Visible = true;
		if (b == null)
			b = el('Modal_Background');
		b.style.top = 0 + 'px';
		b.style.left = 0 + 'px';
		if (this.Modal)
			b.style.display = 'block';
		c.style.display = 'block';
		this.PositionSource = src;
		this.SourceSide = side;
		this.ReCenter();
		this.Resize();
		$(window).resize(function() {
				if (o.Visible)
					o.ReCenter(); 
			});
		//AddResizeMethod('Popup' + id, function() { o.ReCenter(); });
	}
	this.Saving=function()
	{
		ic.clientHeight;
		if(h) return;
		h=ic.innerHTML;
		ic.innerHTML='<table style="height:'+ic.clientHeight+'px;width:'+ic.clientWidth+'px;" cellspacing="0" cellpadding="0"><tr><td><img height="16" width="16" src="'+ Web.Ajax.LoadingImg+'" /><td></tr></table>'
	}
	this.Hide = function(refresh)
	{
		this.MaxContentWidth = 0;
		if (h) { ic.innerHTML = h; h = null }
		b.style.height = '0px';
		b.style.width = '0px';
		b.style.display = 'none';
		c.style.display = 'none';
		this.Visible = false;
		//RemoveResizeMethod('Popup'+id);
		//window.onresize = null;
		if (this.OnHide)
			this.OnHide();
		if (refresh)
			location.href = location.href;

	}
	this.Maximize = function() {
		var w, h;
		var f = el(id + 'IFrame');
		var fd;
		if (f)
			fd=f.contentWindow;
		if (!this.Maxed) {
			this.OldSize = GetSize(table);
			var ds = GetDocSize();
			w = ds.w;
			h = ds.h - this.ExcessHeight;
			this.Maxed = true;
			this.MaxIcon.title = 'Minimize';
		}
		else {
			w = this.OldSize.w;
			h = this.OldSize.h - 20;
			this.Maxed = false;
			this.MaxIcon.title = 'Maximize';
		}

		this.Hide();
		this.SetSize(w, h);
		this.ReCenter();
		this.Show();

		if (fd && fd.PopupMaximized)
			fd.PopupMaximized();

	}
	this.Close=function(){this.Hide();};
	this.SetTitle = function(t) 
	{
		var te=el(id + '_PopupTitleLeft');
		if(te!=null)
			te.innerHTML=t; 
	};

/*
	if (b != null&&!Popup.BackgroundSetup&&document.documentElement)
	{
		document.documentElement.appendChild(b);
		Popup.BackgroundSetup = true;
	}*/
}
Popup.Message = function(html) {
	var id = 'Web.Ajax.MessageBox';
	var e = Append('div', id, 'PopupPanel MessageBox');
	e.innerHTML = '<img class="fr" style="cursor: pointer;" src="resource.axd?X.gif" onclick="Popup.MessageBox.Hide()">' + html;
	var p = new Popup(id);
	Popup.MessageBox = p;
	p.Show();
}