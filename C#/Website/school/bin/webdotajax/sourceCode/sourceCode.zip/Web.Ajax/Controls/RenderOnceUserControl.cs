using System;


namespace Web.Ajax.Controls
{
	/// <summary>
	/// The contents of any User Control that inherits form this class will only appear on the page once.
	/// </summary>
	public class RenderOnceUserControl : UserControl
	{
		#region AlreadyRegistered
		private bool AlreadyRegistered
		{
			get
			{
				object o = System.Web.HttpContext.Current.Items[GetType().Name];
				if (o is bool)
					return (bool)o;
				return false;
			}
			set
			{
				System.Web.HttpContext.Current.Items[GetType().Name] = value;
			}
		}
		#endregion

		#region OnLoad
		protected override void OnLoad(EventArgs e)
		{
			EnableViewState = false;
			if (AlreadyRegistered)
			{
				Visible = false;
				base.OnLoad(e);
			}
			else
				AlreadyRegistered = true;
		} 
		#endregion
	}
}