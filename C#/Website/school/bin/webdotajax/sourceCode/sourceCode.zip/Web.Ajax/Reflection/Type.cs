﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;
using System.Linq;

namespace Web.Ajax.Reflection
{
	public class Type
	{
		public static bool IsNullable(System.Type type)
		{
			if (type.IsGenericType && type.GetGenericTypeDefinition() == typeof(Nullable<>))
				return true;
			return false;
		}

		public static T GetAttribute<T>(ICustomAttributeProvider t, bool inherit)
		{
			var al = t.GetCustomAttributes(typeof(T), inherit);
			if (al != null && al.Length == 1)
				return (T)al[0];
			return default(T);
		}

		public static System.Type GetNormalizedType(System.Type t)
		{
			if(IsNullable(t))
				return Nullable.GetUnderlyingType(t);
			return t;
		}


	}
}
