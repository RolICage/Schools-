﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Collections;

namespace Web.Ajax.Controls
{
	[ToolboxData("<{0}:Signature runat=\"server\" />")]
	public class Signature : Web.Ajax.Controls.WebControl
	{
		public string Data;
		public bool Readonly;

		protected override void OnInit(EventArgs e)
		{
			base.OnInit(e);
			var p = Page as Web.Ajax.Page;
			if (p != null)
			{
				p.RegisterJavascriptFile(Resources.Javascript.Signature);
			}
		}

		protected override void Render(System.Web.UI.HtmlTextWriter writer)
		{
			var html=new StringBuilder(@"<canvas id=""#id#"" class=""sig""  width=""#w#"" height=""#h#"">Your bowser does not support HTML 5. HTML 5 is required for Signature capture.</canvas>
<script type=""text/javascript"" >
	var #id#;
	$(function(){
		#id#=new Signature('#id#', #ro#);#set#
	});
</script>
");
			if (!string.IsNullOrEmpty(Data))
				html.Replace("#set#", "\n\t#id#.Set('" + Data + "');");
			else
				html.Replace("#set#", "");
			html.Replace("#id#", JavascriptId);
			html.Replace("#w#", Width.ToString());
			html.Replace("#h#", Height.ToString());
			html.Replace("#ro#", Readonly.ToString().ToLower());
			writer.Write(html);
		}
	}
}
