using System;
using System.Collections.Generic;
using System.Text;

namespace Web.Ajax.Controls
{
    public class SearchButton : WebControl
    {
        private string onClick;
        public string OnClick
        {
            get { return onClick; }
            set { onClick = value; }
        }

        protected override void Render(System.Web.UI.HtmlTextWriter writer)
        {
            string html="<img src=\"";
            html += Web.Ajax.Resources.ImageUrl(Web.Ajax.Resources.Images.Search);
            html += "\" title=\"Search\" onclick=\"";
            html += OnClick;
            html += "\" style=\"cursor: pointer;padding-top:4px;\" />";
            writer.Write(html);
        }
    }
}
