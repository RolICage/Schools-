﻿function Panel(id, dash)
{
	var tag=el(id);
	var head=el(id+'_head');
	var con=el(id+'_con');
	var opts=el(id+'_opts');

	var dec=el(id+'_dec');
	var inc=el(id+'_inc');
	var min=el(id+'_min');
	var max=el(id+'_max');

	this.ShowDec=true;
	this.ShowInc=true;
	this.ShowMin=true;
	this.ShowMax=true;

	this.Minimised=true;
	this.Colspan=1;
	var o=this;
	this.Source; 
	this.Target;
	this.OnResize;
	this.OnLoad;
	var Loaded=false;
	this.Animating=false;
	this.Visible=false;
	this.Id = id;
	//this.MinWidth=350;
	//this.MinHeight = 350;
	this.SetTarget = function(t)
	{
		/*
		if (!this.Minimised)
		{
			if (t.w < this.MinWidth)
				t.w = this.MinWidth;
			if (t.h < this.MinHeight)
				t.h = this.MinHeight;
		}*/
		this.Source = GetPosition(tag);
		var s = GetSize(tag);
		this.Source.w = s.w;
		this.Source.h = s.h;
		this.Target = t;
	}
	this.MoveToTarget=function()
	{
		if(con)
			if(this.Minimised) con.style.display='none';
			else con.style.display='block';
		if(opts)
			if(this.Minimised) opts.style.display='none';
			else opts.style.display='block';
		if(this.Minimised)
		{
			tag.onclick=function(){return o.Maximize(true);};
			tag.style.cursor='pointer';
		}        
		this.MoveTo(this.Target);
		if(this.OnLoad&&!Loaded&&!this.Minimised)
		{
			if(typeof(this.OnLoad)=='function')
				this.OnLoad();
			else
				eval(this.OnLoad);
			Loaded=true;
		}
	}
	this.Interpolate=function(elapsed, totalTime)
	{
		if(!this.Visible)
			return;
		if(elapsed>totalTime)
		{
			this.Animating=false;
			this.MoveToTarget();
			return;
		}
		if(!this.Animating) //First Call
		{
			if(con)
				con.style.display='none';
			if(opts)
				opts.style.display='none';
			this.Animating=true;
		}
		var per=elapsed/totalTime;
		var s=this.Source;
		var t=this.Target;
		var it=new Object();
		it.x=s.x+((t.x-s.x)*per);
		it.y=s.y+((t.y-s.y)*per);
		it.w=s.w+((t.w-s.w)*per);
		it.h=s.h+((t.h-s.h)*per);
		this.MoveTo(it);
	}
	this.MoveTo=function(t)
	{
		tag.style.left=t.x+'px';
		tag.style.top=t.y+'px';
		tag.style.width=t.w+'px';
		tag.style.height=t.h+'px';
		if(!this.Minimised&&!this.Animating)
			this.ResizeContent();
	}
	this.Hide=function()
	{
		if(opts)
			opts.style.display='none';
		if(con)
			con.style.display='none';
		tag.style.display='none';
	}
	this.Show=function()
	{
		tag.style.display='block';
	}
	this.ResizeContent=function()
	{
		if(!con)
			return;
		var ts=GetSize(tag);
		var hs=GetSize(head);
		var w=ts.w-3;
		var dh=0;
		if(hs)
			dh=hs.h;
		var h=ts.h-dh-3;
		if(w>0)
			con.style.width=w+'px';
		if(h>0)
			con.style.height=h+'px';
		if(this.OnResize)
		{
			var s;
			if(con)
				var s=GetSize(con);
			this.OnResize(s);
		}
	}
	this.Minimize=function(td)
	{
		this.Minimised=true;
		if(td)
		{
			dash.OrderPanel(this);
			dash.Resize(dash.GetMinimisedCount()==1);
			dash.FireOnLayoutChange();
		}
		return false;
	}
	this.MaximizeOnlyMe=function()
	{
		this.Minimised=false;
		dash.MaximizeOnly(this);
	}
	this.Maximize=function(td)
	{
		this.Minimised=false;
		if(td)
		{
			dash.Resize(dash.GetMinimisedCount()==0);
			dash.FireOnLayoutChange();
		}
		tag.onclick=null;
	}
	this.IncrementColspan=function(td)
	{
		if(this.Colspan>=dash.MaxCols)
			return;
		this.Colspan++;
		if(td)
		{
			dash.RepositionPanels();
			dash.FireOnLayoutChange();
		}
	}
	this.DecreaseColspan=function(td)
	{
		if(this.Colspan<=1)
			return;
		this.Colspan--;
		if(td)
		{
			dash.RepositionPanels();
			dash.FireOnLayoutChange();
		}
	}
	this.SetVisibility=function(b)
	{
		this.Visible=b;
		if(b)
			this.Show();
		else
			this.Hide();
		dash.RepositionPanels();
	}
	this.Minimize();
	var ds = GetDocSize();

	/*
	tag.style.width=dash.TaskBarPanelWidth+'px';
	tag.style.height = dash.TaskBarPanelHeight + 'px';
	tag.style.left = ((ds.w / 2) - (dash.TaskBarPanelWidth / 2)) + 'px';
	tag.style.top = ((ds.h / 2) - (dash.TaskBarPanelHeight / 2)) + 'px';
	*/
	
	tag.style.width = '0px';
	tag.style.height = '0px';
	tag.style.left = (ds.w / 2) + 'px';
	tag.style.top = (ds.h / 2) + 'px';
	
	this.Init=function()
	{
		var html='';
		if(opts)
		{
			var sty=Web.Ajax.Style;
			if(this.ShowDec)
				html+='<img id="'+id+'_dec" src="resource.axd?'+sty+'.PanelDecrease.gif" />';
			if(this.ShowInc)
				html+='<img id="'+id+'_inc" src="resource.axd?'+sty+'.PanelIncrease.gif" />';
			if(this.ShowMin)
				html+='<img id="'+id+'_min" src="resource.axd?'+sty+'.Minimize.gif" />';
			if(this.ShowMax)
				html+='<img id="'+id+'_max" src="resource.axd?'+sty+'.Maximize.gif" />';
			opts.innerHTML=html;
		}

		dec=el(id+'_dec');
		inc=el(id+'_inc');
		min=el(id+'_min');
		max=el(id+'_max');

		if(inc)
			inc.onclick=function(){o.IncrementColspan(true);};
		if(dec)
			dec.onclick=function(){o.DecreaseColspan(true);};
		if(min)
			min.onclick=function(){return o.Minimize(true);};
		if(max)
			max.onclick=function(){return o.MaximizeOnlyMe();};
	}
	this.Init();
}








function DashBoard(id)
{
	var dash=el(id);
	var con=el(id+'_content');
	var wb=el(id+'_windowbar');
	var DashPos;
	var DashSize;
	var ContentSize;
	var ContentPos;
	var DocSize;
	var wbs;
	var dh;
	this.Panels=[];
	var TaskBarPos;
	this.TaskBarVPadding=5;
	this.TaskBarHPadding=15;
	this.BarLineHeight=30;
	this.TaskBarPanelWidth=130;
	this.TaskBarPanelHeight=20;
	this.MaxCols=3;
	this.PanelSpacing=6;
	var This=this;
	this.TickSpeed=50;
	this.AnimationTime=500;
	this.IntervalId;
	this.StartTime;
	this.ResizeNeeded=false;
	this.OnLayoutChange;  
	this.GetMinimisedCount=function()
	{
		var mincnt=0;
		for(var i=0;i<this.Panels.length;i++)
		{
			if(this.Panels[i].Minimised)
				mincnt++;
		}
		return mincnt;
	}
	this.GetBarHeight=function()
	{
		var lines=1;
		var mincnt=this.GetMinimisedCount();
		if(mincnt==0)
			lines=0;
		return lines*this.BarLineHeight;
	}
	//this.MinDashHeight = 700;
	this.Resize = function(recalc)
	{
		this.ResizeNeeded = false;
		if (recalc == null || recalc)
		{
			this.HidePanels();
			dash.style.height = '0px';
			con.style.height = '0px';
			con.style.width = '0px';
			wb.style.top = '0px';
			wb.style.width = '0px';
			wb.style.height = this.GetBarHeight() + 'px';
			DocSize = GetDocSize();
			DashPos = GetPosition(dash);
			DashSize = GetSize(dash);
			wbs = GetSize(wb);
			var bugDelta = 5;
			dh = (DocSize.h - DashPos.y - bugDelta);
			//if (dh < this.MinDashHeight)
			//	dh = this.MinDashHeight;
			dash.style.height = dh + 'px';
			var wbh = dh - wbs.h;
			con.style.height = (dh - wbs.h) + 'px';
			con.style.width = DashSize.w + 'px';
			wb.style.left = DashPos.x + 'px';
			wb.style.top = (DashPos.y + wbh) + 'px';
			wb.style.width = DashSize.w + 'px';
			ContentSize = GetSize(con);
			ContentPos = GetPosition(con);
			TaskBarPos = GetPosition(wb);
			this.ShowPanels();
		}
		this.RepositionPanels();
	}
	this.FireOnLayoutChange=function()
	{
		if(this.OnLayoutChange)
			this.OnLayoutChange();
	}
	this.HidePanels=function()
	{
		for(var i=0;i<this.Panels.length;i++)
			this.Panels[i].Hide();
	}
	this.ShowPanels=function()
	{
		for(var i=0;i<this.Panels.length;i++)
		{
			var p=this.Panels[i];
			if(p.Visible)
				p.Show();
		}
	}
	this.FindPanel=function(pid)
	{
		for(var i=0;i<this.Panels.length;i++)
		{
			var p=this.Panels[i];
			if(p.Id==pid)
				return p;
		}
	}
	this.CalculateOpenTarget=function(total, idx, p)
	{
		var cspan=p.Colspan;
		var t={x:0,y:0,w:0,h:0};
		var r=Math.floor(total/this.MaxCols); //r = Number of Rows
		if(total%this.MaxCols>0)
			r++;
		var c=Math.ceil(total/r);	//r = Number of Columns (0 based)
		if(total<=this.MaxCols)
			c=total;
		var w=(ContentSize.w/c)
		var h=(ContentSize.h/r);
		var cc=(idx)%c;				//cc = Current Column Index (0 based)
		if ((cc+cspan)>c)
		{
			cspan=c-cc;
			p.Colspan=cspan;
		}
		var rr=Math.floor(idx/c);	//rr = Current Row Index 
		t.x=ContentPos.x+(cc*w);
		t.y=ContentPos.y+(rr*h);
		t.h=h;
		t.w=w*cspan;
		var OffsetUnit=Math.floor(this.PanelSpacing/2);

		if(cc>0){t.x+=OffsetUnit;t.w-=OffsetUnit;}
		if((cc+(cspan-1))<c)t.w-=OffsetUnit;
		if(rr>0){t.y+=OffsetUnit;t.h-=OffsetUnit;}
		if(rr<r)t.h-=OffsetUnit;

		return t;
	}  
	this.OrderPanel=function(op, nidx)  //if nidx is null move to the end
	{
		if(nidx==null)
			nidx=this.Panels.length-1;
		for(var i=0;i<this.Panels.length;i++)
		{
			var p=this.Panels[i];
			if(p==op&&i!=nidx)
			{
				this.Panels[i]=this.Panels[nidx];
				this.Panels[nidx]=op;
				return;
			}
		}
	}
	this.RepositionPanels=function()
	{
		var TaskBarX=TaskBarPos.x;
		var TaskBarY=TaskBarPos.y+this.TaskBarVPadding;
		var OpenCount=0;
		for(var i=0;i<this.Panels.length;i++)
		{
			var p=this.Panels[i];
			if(p.Minimised&&p.Visible)
			{
				p.SetTarget({x:TaskBarX,y:TaskBarY,w:this.TaskBarPanelWidth,h:this.TaskBarPanelHeight});
				TaskBarX+=(this.TaskBarPanelWidth+this.TaskBarHPadding);
			}
			else if (p.Visible)
			{
				OpenCount+=p.Colspan;
			}
			else
				p.Hide();
		}
		var idx=0;
		for(var i=0;i<this.Panels.length;i++)
		{
			var p=this.Panels[i];

			if(!p.Minimised&&p.Visible)
			{
				var cs=p.Colspan;
				var target=this.CalculateOpenTarget(OpenCount, idx, p);
				if(cs!=p.Colspan)
					return this.RepositionPanels(); //Need to recalc
				p.SetTarget(target);
				idx+=p.Colspan;
			}
		}
		this.BeginAnimation();
	}
	this.MaximizeOnly=function(p)
	{
		var l=this.Panels;
		for(var i=0;i<l.length;i++)
		{
			if(l[i]!=p)
				l[i].Minimize();
		}
		this.Resize(true);
	}
	this.BeginAnimation=function()
	{
		if(this.Animating)
			return;
		this.Animating=true;
		this.StartTime=(new Date()).getTime();
		this.IntervalId=setInterval(function(){This.AnimationTick();},this.TickSpeed);
	}
	this.AnimationTick=function()
	{
		var elapsed = (new Date()).getTime() - this.StartTime; 
		if (elapsed > this.AnimationTime)
		{
			this.Animating=false;
			clearInterval(this.IntervalId);
		}
		for(var i=0;i<this.Panels.length;i++)
		{
			var p=this.Panels[i];
			p.Interpolate(elapsed,this.AnimationTime);
		}
	}
	this.AddPanel=function(p)
	{
		this.Panels[this.Panels.length]=p;
	}
	this.PageTick=function()
	{
		if(this.ResizeNeeded)
		{
			this.Resize();
			this.SetOnResize();
		}
	}
	this.Init=function()
	{
		this.Resize();
		this.SetOnResize();
		setInterval(function(){This.PageTick();},1500);
	}
	this.SetOnResize=function()
	{
		window.onresize=function()
		{
			This.ResizeNeeded=true;
			window.onresize=null;
		};
	}
}
