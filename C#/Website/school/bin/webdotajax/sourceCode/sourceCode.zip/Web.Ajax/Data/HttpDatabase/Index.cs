﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Web.Ajax.Data.HttpDatabase
{
	public class Index : Web.Ajax.Data.Object
	{

		public static Index[] Get(string CollectionPhysicalPath)
		{
			return new Index[]{};
		}

		public void Ensure()
		{

		}
	}
}
