﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Web.Ajax.Controls
{
	public interface IJavascriptControl
	{
		string JavascriptId
		{
			get;set;
		}
	}
}
