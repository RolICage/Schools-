﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Routing;
using System.Web.Compilation;

namespace Web.Ajax.Data.HttpDatabase
{
	public class PageRouteHandler<T> : IRouteHandler where T : IHttpHandler, new()
	{
		public string VirtualPath { get; set; }

		public PageRouteHandler(string virtualPath)
		{
			this.VirtualPath = virtualPath;
		}

		#region IRouteHandler Members

		public IHttpHandler GetHttpHandler(RequestContext requestContext)
		{
			return (VirtualPath != null)
				? (IHttpHandler)BuildManager.CreateInstanceFromVirtualPath(VirtualPath, typeof(T))
				: new T();
		}

		#endregion
	}
}
