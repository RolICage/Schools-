using System;
using System.Collections.Generic;
using System.Text;

namespace Web.Ajax.Controls
{
    public class StyleSheet : WebControl
    {
        private string name;
        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        protected override void OnInit(EventArgs e)
        {
            if (!string.IsNullOrEmpty(Name))
                Page.RegisterStyleSheet(Name);
            base.OnInit(e);
        }


        protected override void Render(System.Web.UI.HtmlTextWriter writer)
        {

        }
    }
}
