using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Reflection;
using System.IO;
using System.Collections;

namespace Web.Ajax
{
    public class Resources
    {
        public static class Images
        {
            //MainMenu
            public static readonly string MainMenuBackground = "MainMenuBackground.gif";
            public static readonly string MainMenuBackgroundOn = "MainMenuBackgroundOn.gif";
            public static readonly string MainMenuFooterBackground = "MainMenuFooterBackground.gif";

            //General
            public static readonly string Loading = "Loading.gif";
            public static readonly string Plus = "Plus.gif";
            public static readonly string Minus = "Minus.gif";
            public static readonly string TreeAngle = "TreeAngle.gif";
            public static readonly string Failure = "Failure.gif";
            public static readonly string Info = "Info.gif";
            public static readonly string Warn = "Warn.gif";
            public static readonly string Lock = "Lock.gif";
            public static readonly string DropDown = "DropDown.gif";
            public static readonly string Unlock = "Unlock.gif";
            public static readonly string Folder = "Folder.gif";
            public static readonly string Report = "Report.gif";
            public static readonly string LogFile = "LogFile.gif";
            public static readonly string Cog = "Cog.gif";      //Small 12x12
            public static readonly string Up = "Up.gif";        //Small 12x12
            public static readonly string Down = "Down.gif";    //Small 12x12
            public static readonly string Man = "Man.gif";      //Small 12x12
            public static readonly string Money = "Money.gif";  //Small 12x12
            public static readonly string Calculator = "Calculator.gif";
            public static readonly string Search = "Search.gif";
            public static readonly string Building = "Building.gif";
            public static readonly string User = "User.gif";
            public static readonly string ViewParent = "ViewParent.gif";
			public static readonly string Coins = "Coins.gif";
			public static readonly string Clock = "Clock.gif";
			public static readonly string Brick = "Brick.gif";
			public static readonly string Basket = "Basket.gif";
			public static readonly string Relationship = "Relationship.gif";
			public static readonly string TagPage = "TagPage.gif";
			public static readonly string Tag = "Tag.gif";
			public static readonly string Television = "Television.gif";
			public static readonly string Telephone = "Telephone.gif"; 
			public static readonly string Grid = "Grid.gif";
			public static readonly string Attributes = "Attributes.gif";

            //Calendar
            public static readonly string Calendar = "Calendar.gif";
            public static readonly string CalendarDown = "CalendarDown.gif";
            public static readonly string CalendarLeft = "CalendarLeft.gif";
            public static readonly string CalendarRight = "CalendarRight.gif";
            
            //Ajax Grid
            public static readonly string FirstPage = "FirstPage.gif";
            public static readonly string LastPage = "LastPage.gif";
            public static readonly string NextPage = "NextPage.gif";
            public static readonly string PrevPage = "PrevPage.gif";
            public static readonly string Asc = "Asc.gif";
            public static readonly string AscGrey = "AscGrey.gif";
            public static readonly string Desc = "Desc.gif";
            public static readonly string DescGrey = "DescGrey.gif";
            public static readonly string Delete = "Delete.gif";
            public static readonly string Add = "Add.gif";
            public static readonly string GridHeading = "GridHeading.gif";
            
            //Popup Images
            public static readonly string Close = "Close.png";
			public static readonly string CloseSmall = "CloseSmall.gif";
            public static readonly string Resize = "Resize.gif";
            
            //TabStrip Images
            public static readonly string TabLeft = "TabLeft.gif";
            public static readonly string TabMiddle = "TabMiddle.gif";
            public static readonly string TabRight = "TabRight.gif";
            public static readonly string TabLeftSelected = "TabLeftSelected.gif";
            public static readonly string TabMiddleSelected = "TabMiddleSelected.gif";
            public static readonly string TabRightSelected = "TabRightSelected.gif";
        }

        public static class StyleSheets
        {
            public static readonly string Page = "Page.css";
            public static readonly string MainMenu = "MainMenu.css";
            public static readonly string Common = "Common.css";
			public static readonly string AjaxGrid = "AjaxGrid.css";
            public static readonly string Tree = "Tree.css";
            public static readonly string Questions = "Questions.css";
            public static readonly string Popup = "Popup.css";
            public static readonly string PopupMenu = "PopupMenu.css";
            public static readonly string Tabs = "Tabs.css";
            public static readonly string Calendar = "Calendar.css";
            public static readonly string Object = "Object.css";
            public static readonly string Dashboard = "Dashboard.css";
			public static readonly string Tablet = "Tablet.css";


        }

        public static class Javascript
        {
            public static readonly string Ajax = "Ajax.js";
            public static readonly string MainMenu = "MainMenu.js";

			public static readonly string AjaxControl = "AjaxControl.js";
            public static readonly string AjaxGrid = "AjaxGrid.js";
            public static readonly string Tree = "Tree.js";
            public static readonly string Questions = "Questions.js";
            public static readonly string Popup = "Popup.js";
            public static readonly string PopupMenu = "PopupMenu.js";
            public static readonly string DragDrop = "DragDrop.js";
            public static readonly string Tabs = "Tabs.js";
            public static readonly string Validator = "Validator.js";
            public static readonly string Calendar = "Calendar.js";
            public static readonly string Object = "Object.js";
            public static readonly string LazyLoading = "LazyLoading.js";
            public static readonly string SlidePanel = "SlidePanel.js";
            public static readonly string Dashboard = "Dashboard.js";
			public static readonly string TypeSelection = "TypeSelection.js";

			public static readonly string Svg = "Svg.js";
			public static readonly string Signature = "Signature.js";

			public static readonly string jQuery = "jQuery.js";
			public static readonly string Tabby = "Tabby.js";

        }

        public static bool ResourceExists(string name)
        {
            if (string.IsNullOrEmpty(name))
                return false;

            if (typeof(Resources).Assembly.GetManifestResourceInfo(name) != null)
                return true;            
            
            try
            {
                Assembly a = Web.Ajax.Reflection.Assembly.GetAssembly(name);
                if (a != null)
                    return true;
            }
            catch 
            { 
            }
            return false;
        }

        public static string GetResouceUrl(string name)
        {
			//return "resource.axd?" + name;
			return Web.Ajax.Page.StaticResolveUrl("~/resource.axd?" + name);
        }

        private static readonly string DefaultStyle = "Standard";

        private static readonly string StyleBase = "Web.Ajax.Styles.";

        public static string GetClientName(string ResourceName)
        {
            if (string.IsNullOrEmpty(ResourceName))
                return "Null";
            if (ResourceName.Contains(".js"))
                return "Web.Ajax.Javascript." + ResourceName;
            return Configuration.Settings.Current.Style + "." + ResourceName;
        }

        public static string FullResourceName(string ShortName)
        {
            if (string.IsNullOrEmpty(ShortName))
                return null;
            
            string[] parts=ShortName.Split('.');
            if (parts.Length > 3)  //Assume ShortName is FullName 
                return ShortName;

            if (ShortName.Contains(".js"))
                return "Web.Ajax.Javascript." + ShortName;
            string StyleSubFolder = ".Images.";
            if (ShortName.Contains(".css"))
                StyleSubFolder = ".";

            string FullName=null;
            if (parts.Length == 3)     //Assume first part is Style
            {
                ShortName=parts[1] + "." + parts[2];
                FullName = StyleBase + parts[0] + StyleSubFolder + ShortName;
            }
            if (!ResourceExists(FullName))
                FullName = StyleBase + Configuration.Settings.Current.Style + StyleSubFolder + ShortName;
            if (!ResourceExists(FullName))
                FullName = StyleBase + DefaultStyle + StyleSubFolder + ShortName;
            return FullName;
        }

        public static string ImageUrl(string name)
        {
            return GetResouceUrl(GetClientName(name)); 
        }

		public static string ImageHtml(string name)
		{
			return "<img src=\"" + ImageUrl(name) + "\" />";
		}

        public static string StylesUrl(string name)
        {
            return GetResouceUrl(GetClientName(name));             
        }

        public static string JavascriptUrl(string name)
        {
            return GetResouceUrl(GetClientName(name)); 
        }

        public static void ReplaceImageUrl(StringBuilder html, string Token, string ImageName)
        {
            html.Replace(Token, ImageUrl(ImageName));
        }


        public static string GetContentType(string ResourceName)
        {
            if (string.IsNullOrEmpty(ResourceName))
                return "";
            string[] parts = ResourceName.Split('.');
            string ext = parts[parts.Length - 1];
            switch (ext)
            {
                case "css":
                    return "text/css";
                case "js":
                    return "text/javascript";
                case "gif":
                    return "image/gif";
                case "png":
                    return "image/png";
                default:
                    return "text/html";
            }
        }

        public class Resource
        {
            public string ShortName;
            public string FullName;

            private Assembly assembly;
            public Assembly GetAssembly()
            {
                if (assembly == null)
                {
                    assembly=Web.Ajax.Reflection.Assembly.GetAssembly(FullName);
                }
                return assembly;
            }

            public Resource(string ShortName)
            {
                this.ShortName = ShortName;
                this.FullName = Resources.FullResourceName(this.ShortName);
            }

            private string contentType;
            public string GetContentType()
            {
                if(contentType==null)
                    contentType=Resources.GetContentType(ShortName);
                return contentType;
            }

            public Stream GetStream()
            {                
                Assembly a = GetAssembly();
                if (a != null)
                    return a.GetManifestResourceStream(FullName);
                return null;
            }

            private byte[] bytes;
            public byte[] GetBytes()
            {
                //if (bytes == null)
                {
                    using (Stream s = GetStream())
                    {
                        if (s == null)
                            return null;
                        long length = s.Length;
                        bytes = new byte[length];
                        s.Read(bytes, 0, (int)length);
                    }
                }
                return bytes;
            }

            private DateTime? assemblyBuildTime;
            public DateTime GetAssemblyBuildTime()
            {
                if (!assemblyBuildTime.HasValue)
                {
                    Assembly a = GetAssembly();
                    if (a != null)
                        assemblyBuildTime = Web.Ajax.Reflection.Assembly.GetAssemblyBuildTime(a);
                    else
                        assemblyBuildTime=DateTime.Now;
                }
                return assemblyBuildTime.Value;
            }
        }

        private static Hashtable hash = new Hashtable();
        public static Resource GetResource(string ResourceName)
        {
            Resource r=(Resource)hash[ResourceName];
            if (r == null)
            {
                r = new Resource(ResourceName);
                hash[ResourceName] = r;
            }
            return r;
        }
    }
}
