using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;

namespace Web.Ajax.Configuration
{
    public class TabStripConfiguration : ConfigurationElement
    {
        /// <summary>
        /// If true draws a column containing an &nbsp; between tab titles.
        /// </summary>
        [ConfigurationProperty("SpaceBetweenTabs", DefaultValue = 0)]
        public int SpaceBetweenTabs
        {
            get
            { return (int)this["SpaceBetweenTabs"]; }
            set
            { this["SpaceBetweenTabs"] = value; }
        }

        /// <summary>
        /// If true draws two row in tab titles.
        /// </summary>
        [ConfigurationProperty("Template", DefaultValue = 3)]
        public int Template
        {
            get
            { return (int)this["Template"]; }
            set
            { this["Template"] = value; }
        }

        /// <summary>
        /// The width of the left and right sections of the tab title.
        /// </summary>
        [ConfigurationProperty("LeftRightWidth", DefaultValue = 5)]
        public int LeftRightWidth
        {
            get
            { return (int)this["LeftRightWidth"]; }
            set
            { this["LeftRightWidth"] = value; }
        }
        
    }
}
