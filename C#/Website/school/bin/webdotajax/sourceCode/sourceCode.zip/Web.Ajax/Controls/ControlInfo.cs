using System;
using System.Collections.Generic;
using System.Text;

namespace Web.Ajax.Controls
{
    public class ControlInfo
    {
        public Action Action;
        public Parameter[] Parameters;
        public string OnComplete;
        

        public string GetParameter(string key)
        {
            return Web.Ajax.Controls.Parameter.GetValue(Parameters, key);
        }

		public short? GetShortParameter(string key)
		{
			try
			{
				return short.Parse(GetParameter(key));
			}
			catch
			{
			}
			return null;
		}

        public int? GetIntParameter(string key)
        {
            try
            {
                return int.Parse(GetParameter(key));
            }
            catch
            {
            }
            return null;
        }

        public long? GetLongParameter(string key)
        {
            try
            {
                return long.Parse(GetParameter(key));
            }
            catch { return null; }
        }

        public DateTime? GetDateTimeParameter(string key)
        {
            try
            {
                return (DateTime?)Json.ConvertFromJson(typeof(DateTime?),GetParameter(key));
            }
            catch { return null; }
        }

		public bool? GetBoolParameter(string key)
		{
			try
			{
				return bool.Parse(GetParameter(key));
			}
			catch { return null; }
		}

        public string[] GetStringArrayParameter(string key)
        {
            string s=GetParameter(key);
            if (!string.IsNullOrEmpty(s))
                return s.Split(',');
            return null;        
        }

		public int[] GetIntArrayParameter(string key)
		{
			var list = new List<int>();
			var parts = GetStringArrayParameter(key);
			if (parts != null)
			{
				foreach (var s in parts)
				{
					list.Add(int.Parse(s));
				}
			}
			return list.ToArray();
		}

		public long[] GetLongArrayParameter(string key)
		{
			var list = new List<long>();
			var parts = GetStringArrayParameter(key);
			if (parts != null)
			{
				foreach (var s in parts)
				{
					list.Add(long.Parse(s));
				}
			}
			return list.ToArray();
		}

        public object GetEnumParameter(string key, Type t)
        {
            try
            {
                string s=GetParameter(key);
                if (!string.IsNullOrEmpty(s))
                    return (Enum)Enum.Parse(t,s);
            }
            catch { }
            return null;

        }

        public void SetParameter(string Name, string Value)
        {
            if (string.IsNullOrEmpty(Name))
                return;

            if (Parameters != null)
            {
                for (int i = 0; i < Parameters.Length; i++)
                {
                    if (Parameters[i].Name == Name)
                    {
                        Parameters[i].Value = Value;
                        return;
                    }
                }
            }
            List<Parameter> list = new List<Parameter>();
            if (Parameters != null)
                list.AddRange(Parameters);
            list.Add(new Parameter(Name, Value));
            Parameters = list.ToArray();
        }
    }
}
