﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Web.Ajax.Logging
{
    public enum Roll
    {
        Request=1,
        Daily=2
    }
}
