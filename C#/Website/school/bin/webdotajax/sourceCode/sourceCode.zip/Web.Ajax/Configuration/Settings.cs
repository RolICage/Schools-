using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;
using System.Web;
using System.IO;

namespace Web.Ajax.Configuration
{
    public class Settings : ConfigurationSection
    {
		[ConfigurationProperty("DataFolder", DefaultValue = "c:\\Data\\")]
		public string DataFolder
		{
			get
			{
				string s = (String)this["DataFolder"];
				if (!Directory.Exists(s))
					Directory.CreateDirectory(s);
				return s;
			}
		}

        [ConfigurationProperty("ImageBaseUrl", DefaultValue = "~/Images")]
        public string ImageBaseUrl
        {
            get
            {
                return (String)this["ImageBaseUrl"]; 
            }
            set
            {
                this["ImageBaseUrl"] = value; 
            }
        }

        [ConfigurationProperty("Style", DefaultValue = "Standard")]
        public string Style
        {
            get
            {
                string s=null;
                if(HttpContext.Current!=null)
                {
                    s=(string)HttpContext.Current.Items["Web.Ajax.Style"];
                    if (string.IsNullOrEmpty(s) && HttpContext.Current.Session!=null)
                        s = (string)HttpContext.Current.Session["Web.Ajax.Style"];

                    /*  Read from cookie
                    if (string.IsNullOrEmpty(s))
                    {
                        HttpCookie c=HttpContext.Current.Request.Cookies["Web.Ajax.Style"];
                        if (c != null && !string.IsNullOrEmpty(c.Value))
                            s = c.Value;
                    }
                     */
                }
                if (string.IsNullOrEmpty(s))
                    s = (String)this["Style"];
                return s;
            }
            set
            {
                if (HttpContext.Current != null)
                    HttpContext.Current.Items["Web.Ajax.Style"]=value;
            }
        }

        [ConfigurationProperty("XorKey", DefaultValue = 8)]
        public int XorKey
        {
            get
            {
                return (int)this["XorKey"];
            }
            set
            {
                this["XorKey"] = value;
            }
        }

        [ConfigurationProperty("UsePageStyle", DefaultValue = false)]
        public bool UsePageStyle
        {
            get
            {
                return (bool)this["UsePageStyle"];
            }
            set
            {
                this["UsePageStyle"] = value;
            }
        }

		[ConfigurationProperty("CacheResources", DefaultValue = false)]
		public bool CacheResources
		{
			get
			{
				return (bool)this["CacheResources"];
			}
			set
			{
				this["CacheResources"] = value;
			}
		}

        
        [ConfigurationProperty("ClientTimeout", DefaultValue = null)]
        public int? ClientTimeout
        {
            get
            {
                object o=this["ClientTimeout"];
                if (o is int)
                    return (int)o;
                return null;
            }
        }

        [ConfigurationProperty("ValidatorType", DefaultValue = "Image")]
        public string ValidatorType
        {
            get
            {
                return (string)this["ValidatorType"];
            }
        }

		[ConfigurationProperty("CallPageInit", DefaultValue = false)]
		public bool CallPageInit
		{
			get
			{
				return (bool)this["CallPageInit"];
			}
			set
			{
				this["CallPageInit"] = value;
			}
		}

        public static Settings Current
        {
            get
            {
                object o=ConfigurationManager.GetSection("Web.Ajax");
                if (o is Settings)
                    return (Settings)o;
                return new Settings();
            }
        }

        [ConfigurationProperty("TabStripConfiguration")]
        public TabStripConfiguration TabStrip
        {
            get
            { return (TabStripConfiguration)this["TabStripConfiguration"]; }
            set
            { this["TabStripConfiguration"] = value; }
        }
    }
}
