﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Web.Ajax.Data
{
	public class Search
	{
		public static bool SearchStringArray(string s, string[] values, bool ignorecase)
		{
			if (s == null||values==null)
				return false;
			if (ignorecase)
				s = s.ToLower();
			var parts = s.Split(' ');
			var matchonall = true;
			foreach (var p in parts)
			{
				var matchonp = false;
				foreach (var v in values)
				{
					if (string.IsNullOrEmpty(v))
						continue;
					var nv = v;
					if (ignorecase)
						nv = nv.ToLower();
					if (nv.IndexOf(p) > -1)
					{
						matchonp = true;
						continue;
					}
				}
				matchonall = matchonall && matchonp;
				if (!matchonall)
					return false;
			}
			return matchonall;
		}
	}
}
