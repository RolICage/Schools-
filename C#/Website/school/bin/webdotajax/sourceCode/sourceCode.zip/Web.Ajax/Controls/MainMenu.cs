using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;

namespace Web.Ajax.Controls
{
    [ToolboxData("<{0}:MainMenu runat=\"server\"></{0}:MainMenu>")]
    [ParseChildren(false)]
    public class MainMenu : AjaxControl
    {
        #region MenuItems
        private MainMenuItem[] menuItems;
        public MainMenuItem[] MenuItems
        {
            get
            {
                if (menuItems == null)
                {
                    List<MainMenuItem> items = new List<MainMenuItem>();
                    for (int i = 0; i < Controls.Count; i++)
                    {
                        if (Controls[i] is Web.Ajax.Controls.MainMenuItem)
                            items.Add(Controls[i] as Web.Ajax.Controls.MainMenuItem);
                    }
                    menuItems = items.ToArray();
                }
                return menuItems;
            }
        }
        #endregion

        #region MenuLinks
        private MainMenuLink[] menuLinks;
        public MainMenuLink[] MenuLinks
        {
            get
            {
                if (menuLinks == null)
                {
                    List<MainMenuLink> items = new List<MainMenuLink>();
                    for (int i = 0; i < Controls.Count; i++)
                    {
                        if (Controls[i] is Web.Ajax.Controls.MainMenuLink)
                            items.Add(Controls[i] as Web.Ajax.Controls.MainMenuLink);
                    }
                    menuLinks = items.ToArray();
                }
                return menuLinks;
            }
        }
        #endregion

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            Web.Ajax.Page p = Page as Web.Ajax.Page;
            if (p != null)
            {
                p.RegisterStyleSheet(Web.Ajax.Resources.StyleSheets.MainMenu);
            }
        }

        protected override void Render(System.Web.UI.HtmlTextWriter writer)
        {
            if (!Visible)
                return;

            writer.WriteLine("<div class=\"MainMenu\">");

            writer.WriteLine("<div class=\"MainMenuTabs\">");
            MainMenuLink[] links = MenuLinks;
            if (links.Length > 0)
            {
                writer.WriteLine("<div class=\"MainMenuLinks\">");
                for (int i = 0; i < links.Length; i++)
                {
                    if (i > 0)
                        writer.Write("|");
                    links[i].Render(writer);
                }
                writer.WriteLine("</div>");
            }

            writer.WriteLine("<ul class=\"MainMenuList\">");
            MainMenuItem[] items = MenuItems;
            for (int i = 0; i < items.Length; i++)
                items[i].Render(writer);
            writer.WriteLine("</ul>");
            writer.WriteLine("</div>");

            writer.WriteLine("<div class=\"MainMenuFooter\"></div>");

            writer.WriteLine("</div>");           
            
        }
    }

    [ToolboxData("<{0}:MainMenuItem runat=\"server\" Title=\"?\" Url=\"?\" />")]
    public class MainMenuItem : WebControl
    {
        private string title;
        public string Title
        {
            get { return title; }
            set { title = value; }
        }

        private string url;
        public string Url
        {
            get { return url; }
            set { url = value; }
        }

        private bool rendered = false;
        public new void Render(System.Web.UI.HtmlTextWriter writer)
        {
            if (rendered || !Visible)
                return;
            string u = ResolveUrl(Url);
            bool on = false;
			try
			{
				if (Page.Request.Url.AbsolutePath.ToLower().IndexOf(u.ToLower()) > -1)
					on = true;
			}
			catch { }

            writer.Write("<li class=\"MainMenuListItem\">");
            writer.Write("<a class=\"MainMenuListItemLink" + (on ? "Over" : "") + "\" ");
            if (!on)
            {
                writer.Write("onmouseover=\"this.className='MainMenuListItemLinkOver';this.firstChild.className='MainMenuListItemSpanOver';\" ");
                writer.Write("onmouseout=\"this.className='MainMenuListItemLink';this.firstChild.className='MainMenuListItemSpan';\" ");
            }
            writer.Write(" href=\"");
            writer.Write(u);
            writer.Write("\" ><span class=\"MainMenuListItemSpan" + (on ? "Over" : "") + "\" >");
            writer.Write(Title);
            writer.Write("</span></a></li>");
            writer.WriteLine("");
            rendered = true;
        }
    }


    [ToolboxData("<{0}:MainMenuLink runat=\"server\" Title=\"?\" Url=\"?\" />")]
    public class MainMenuLink : WebControl
    {
        private string title;
        public string Title
        {
            get { return title; }
            set { title = value; }
        }

        private string url;
        public string Url
        {
            get { return url; }
            set { url = value; }
        }

        private string onClick;
        public string OnClick
        {
            get { return onClick; }
            set { onClick = value; }
        }

        private bool bold;
        public bool Bold
        {
            get { return bold; }
            set { bold = value; }
        }

		public string Image { get; set; }

        private bool rendered = false;
        public new void Render(System.Web.UI.HtmlTextWriter writer)
        {
            if (rendered || !Visible)
                return;           
			if(!string.IsNullOrEmpty(Image))
			{
				writer.Write("<img src=\"resource.axd?Standard."+Image+"\" class=\"Clickable MainMenuLink\" title=\""+Title+"\" onclick=\""+OnClick+"\" />");
				return;
			}
            writer.Write("<a class=\"MainMenuLink\" ");
            if (!string.IsNullOrEmpty(Url))
                writer.Write("href=\""+ResolveUrl(Url)+"\" ");
            if (!string.IsNullOrEmpty(OnClick))
                writer.Write("onclick=\"" + OnClick + "\" ");
            writer.Write(">");
            if (Bold)
                writer.Write("<strong>");
			writer.Write(Title);				
            if (Bold)
                writer.Write("</strong>");
            writer.Write("</a>");
            writer.WriteLine("");
            rendered = true;
        }
    }
}
