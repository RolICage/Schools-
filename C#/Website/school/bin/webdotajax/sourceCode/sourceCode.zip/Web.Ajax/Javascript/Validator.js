var Validators=[];
function Validator(id, added)
{
	if(!added)
	{
		for(var i=0;i<Validators.length;i++)
		{
			if(Validators[i].Id==id)
				return Validators[i];
		}
		Validators[Validators.length]=this;
	}
	this.Id=id;
	this.SourceId=null;
	this.Control=null;
	this.RegEx=null;
	this.Required=false;
	this.Function=null;
	this.Message=null;
	this.Group=null;
	this.PropertyName=null;
	this.Answer=null;
	this.Type='Image';
	if(Web.Ajax.ValidatorType)
		this.Type=Web.Ajax.ValidatorType;
	var tag;
	var This=this;
	this.Init=function()
	{
		tag=el(id);
	}
	this.Init();
	this.GetAnswer=function()
	{
		if(!this.SourceId)
			return null;
		var e=el(this.SourceId);
		if(e)
		{
			if(e.type=='select-multiple')
			{
				this.Answer=[];
				for(var i=0;i<e.options.length;i++)
				{
					if(e.options[i].selected)
						this.Answer[this.Answer.length]=e.options[i].value;
				}
			}
			else if(e.type=='checkbox')
				this.Answer=e.checked
			else if(e.type=='radio')
			{
				var rds=document.getElementsByName(this.SourceId);
				for(var i=0;i<rds.length;i++)
					if(rds[i].checked)
						this.Answer=rds[i].value;
			}
			else
				this.Answer=e.value;

		}
		return this.Answer;
	}
	this.SetAnswer = function(o) {
		var e = el(this.SourceId);
		if (e) {
			if (e.type == 'select-multiple') {
				for (var i = 0; i < e.options.length; i++)
					e.options[i].selected = false;
				if (o && o.length) {
					for (var i = 0; i < o.length; i++) {
						var setval = o[i];
						for (var j = 0; j < e.options.length; j++) {
							checkval = e.options[j].value;
							if (setval == checkval) {
								e.options[j].selected = true;
							}
						}
					}
				}
				return;
			}
			if (o == null)
				o = '';
			else if (e.type == 'checkbox')
				e.checked = o && o != 'false';
			else if (e.type == 'radio') {
				var rds = document.getElementsByName(this.SourceId);
				for (var i = 0; i < rds.length; i++)
					if (rds[i].value == o)
					rds[i].checked = true;
				else
					rds[i].checked = false;
			}
			else {
				if (this.format) {
					var fmt = eval(this.format);
					o = fmt(o);
				}
				e.value = o;
			}
		}
	}
	this.Hide=function()
	{
		if(this.Type=='Popup')
		{
			var pid=id+'_Popup';
			var e=el(pid);
			if(e)
				e.style.display='none';
		}
		else
		{
			if(!tag)
				this.Init();
			if(tag)
				tag.style.visibility='hidden';
		}
	}
	this.Show=function(t)
	{
		//var src=el(this.SourceId);
		if(this.Type=='Popup')
		{
			var pid=id+'_Popup';
			var e=Append('div', pid, 'ValidatorPopup');
			e.innerHTML='<img src="resource.axd?Standard.ValidatorAngle.gif" class="ValidatorAngle" /><span class="ValidatorMessage">'+t+'</span>';
			var p=new PopupMenu(pid,4,0,'r+');
			p.HideEvent='Click';
			p.ShowFromNewSource(el(this.SourceId));
		}
		else
		{
			if(!tag)
				this.Init();
			if(tag)
			{
				tag.style.visibility='visible';
				if(t)
					tag.title=t;
			}
		}
	}
	this.IsSourceVisible = function() {
		var e = el(this.SourceId);
		if (!e || e.style.display == 'none' || e.scrollWidth == 0 || e.className.indexOf('disabled') > -1)
			return false;

		//IE6 IE7 IE8 children don't inherit display so hack to check parent chain
		//if (Web.Ajax.Browser == 'IE6' || Web.Ajax.Browser == 'IE7') {
		if (Web.Ajax.Browser.indexOf('IE') != -1) {
			var par = e;
			while (par.parentNode && par.parentNode.style)//&&par.parentNode.style.display)
			{
				if (par.parentNode.style.display == 'none')
					return false;
				par = par.parentNode;
			}
		}
		return true;
	}
	this.IsValid = function() {
		var valid = true;
		var e = el(this.SourceId);
		this.Hide();

		if (!this.IsSourceVisible())
			return true;

		var ans = this.GetAnswer();
		var m = this.Message ? this.Message : 'Validation Error';
		if (this.Required) {
			if (ans == null || ans == '' || ans == 'Select...' || ans == '- Select -') {
				valid = false;
				m = 'This is a required field.';
			}
		}
		if (valid && this.RegEx) {
			var r = Validator.TranslateRegex(this.RegEx);
			if (ans && ans != '')
				valid = (ans.match(eval(r)) != null);
		}
		if (valid && this.MatchId) {
			if (ans && ans != '') {
				var mv = this.Find(this.MatchId);
				if (mv)
					valid = (ans == mv.GetAnswer());
				else {
					try { valid = (ans == eval(this.MatchId).GetAnswer()); } catch (e) { }
				}
			}
		}
		if (valid && this.Function) {
			var vf = eval(this.Function);
			valid = vf(ans);
		}
		if (!valid)
			this.Show(m);
		return valid;
	}
	this.GetClientHtml=function()
	{
		var html='';
		if(this.Type=='Popup')
			html+='<span id="'+id+'" ></span>';
		else
			html+='<img id="'+id+'"  src="'+ImageUrl('Failure.gif')+'" style="visibility:hidden;" />';
		return html;
	}
	this.Find=function(fid)
	{
		for(var i=0;i<Validators.length;i++)
		{
			var v=Validators[i];
			if(v.SourceId==fid)
				return v;
		}
		return null;
	}
}
Validator.TranslateRegex = function (r) {
	if (r == 'int')
		return '/^-?\\d*$/';
	if (r == 'int+')
		return '/^\\d*$/';
	if (r == 'decimal(2)')
		return '/^-?\\d*\\.?\\d{0,2}$/';
	if (r == 'decimal(2)+')
		return '/^\\d*\\.?\\d{0,2}$/';
	if (r == 'email')
		return '/^([a-zA-Z0-9\\\'_\\.\\-])+\\@(([a-zA-Z0-9\\-])+\\.)+([a-zA-Z0-9]{2,4})+$/';
	if (r == 'password')
		return '/^.*(?=.{8,})((?=.*\\d)|(?=.*\\W+))(?=.*[A-Z]).*$/';
	if (r == 'ipaddress')
		return '/^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/';
	return r;
}
if(!Page)
	var Page={};
Page.Init = function(elid)
{
	var initfunction = function()
	{
		var e = this;
		var id = e.id;
		if (!id)
			id = e.name;
		if (!id || id == '' || id == '__VIEWSTATE' || e.type == 'button' || e.type == 'hidden' || e.className == 'DateTextBox')
			return;
		var parts = id.split('.');
		if (parts.length < 2)
		{
			var obj = e.attributes['obj'];
			if(!obj)
				return;
			parts=[obj.nodeValue, id]
		}
		var req = e.attributes['required'];
		var r = e.attributes['regex'];
		var m = e.attributes['message'];
		var f = e.attributes['function'];
		var fmt = e.attributes['format'];

		var mid = e.attributes['matchid'];
		var t = e.attributes['valtype'];
		var vid = id + '.Val';
		var v = new Validator(vid);
		if (r) v.RegEx = r.nodeValue;
		if (m) v.Message = m.nodeValue;
		if (f) v.Function = f.nodeValue;
		if (fmt) v.format = fmt.nodeValue;
		if (mid) v.MatchId = mid.nodeValue;
		if (t) v.Type = t.nodeValue;
		v.Group = parts[0];
		v.PropertyName = id.substr(parts[0].length + 1);
		v.SourceId = id;
		if (req) v.Required = req.nodeValue == 'true';
		var img = document.getElementById(vid);
		if (v.Type == 'Image' && !img)
		{
			img = document.createElement('img');
			img.setAttribute('id', vid);
			img.setAttribute('src', ImageUrl('Failure.gif'));
			img.className = 'Validator';
			img.style.visibility = 'hidden';
			insertAfter(img, e);
		}
	}
	if (elid)
		$(el(elid)).each(initfunction);
	else
		$('input,select,textarea').each(initfunction);
}
Page.ReInit = function()
{
	Validators = [];
	Page.Init();
}
Page.Validate = function(g) {
	var r = true;
	if (g && g.constructor == Array) {
		for (var i = 0; i < g.length; i++) {
			r &= Page.Validate(g[i]);
		}
	}
	else {
		for (var i = 0; i < Validators.length; i++) {
			var v = Validators[i];
			if (g && ((v.Group + '.' + v.PropertyName).indexOf(g) != 0))
				continue;
			r &= v.IsValid();
			if (!v.IsValid()) {
				v.IsValid();
			}
		}
	}
	return r;
}
function SetProperty(o, pn, v)
{
	if(!o||!pn)
		return;
	var parts=pn.split('.');
	for(var i=0;i<parts.length;i++)
	{
		if(i==parts.length-1)
			o[parts[i]]=v;
		else
		{
			if(o[parts[i]]==null)
				o[parts[i]]={};
			o=o[parts[i]];
		}
	}
}
Page.GetObject = function(g, old) {
	var r = {};
	for (var i = 0; i < Validators.length; i++) {
		var v = Validators[i];
		if (g && v.Group != g)
			continue;
		if (v.IsSourceVisible&&!v.IsSourceVisible())
			continue;
		if (v.constructor == Validator || v.customValidator) {
			var pn = v.PropertyName ? v.PropertyName : v.SourceId;
			SetProperty(r, pn, v.GetAnswer());
		}
		if (window.Calendar && v.constructor == Calendar && v.PropertyName) {
			SetProperty(r, v.PropertyName, v.Date);
		}
	}
	if (old)
		r = merge(old, r);
	return r;
}
Page.SetObject=function(o, g)
{
	if(!o)
		return;
	for(var i=0;i<Validators.length;i++)
	{
		var v=Validators[i];
		if(g&&v.Group!=g)
			continue;
		//New code
		if(v.PropertyName!=null)
		{
			var prts=v.PropertyName.split('.');
			var ctx=o;
			for(var j=0;j<prts.length;j++)
			{
				if(ctx)
					ctx=ctx[prts[j]];
			}
			if(ctx!=null)
			{
				v.SetAnswer(ctx);
				continue;
			}
		}
		else if (v.SourceId!=null)
		{
			v.SetAnswer(o[v.SourceId]);
			continue;
		}
	}
	$('span').each(function()
						{
							var e=this;
							var id=e.id;
							var parts=id.split('.');
							if(parts.length<2||parts[0]!=g)
								return;
							var ctx=o;
							for(var j=1;j<parts.length;j++)
							{
								if(ctx)
									ctx=ctx[parts[j]];
							}
							if(ctx==null)
								return;
							var fmt=$(e).attr('format');
							if(fmt)
							{
								if(fmt=='date'&&window.Calendar!=null)
								{
									var c=new Calendar();
									$(e).html(GetFormatString(ctx));
								}
								else if(window[fmt]!=null)
								{
									var fn=eval(fmt);
									if (fn) {
										e.formatFunction=fn;
										$(e).html(e.formatFunction(ctx));
									}
								}
							}
							else
								$(e).html(ctx);
							
						});
}
Page.HideAction = function (t, id) {
	var a = el(id);
	if (a) {
		a.style.display = 'none';
		var l = el(id + '.Loading');
		if (!l) {
			var le = document.createElement('span');
			le.setAttribute('id', id + '.Loading');
			var html = '';
			if (t)
				html += '<span id="' + id + '.Loading.Text">' + t + '</span>';
			html += ImageHtml(ImageUrl('Loading.gif'));
			le.innerHTML = html;
			insertAfter(le, a);
			l = le;
		}
		if (l) {
			l.style.display = 'inline';
			if (t) {
				var te = el(id + '.Loading.Text');
				if (te)
					te.innerHTML = t;
			}
		}
	}
	else {
		$('ul.pho').append('<li id="Actions.Loading"><span class="loading">please wait...</span></li>');
		$('ul.pho li.action').each(function () {
			if ($(this).is(':visible'))
				$(this).addClass('hiddenDuringRequest').hide();
		});
	}
}
Page.ShowAction = function (id) {
	var a = el(id);
	if (a) {
		a.style.display = 'inline';
		var l = el(id + '.Loading');
		if (l)
			l.style.display = 'none';
	}
	else {
		$('#Actions\\.Loading').remove();
		$('ul.pho li.hiddenDuringRequest').show();
	}
}
Page.SaveObject=function(on, ajax, ocf, st, sid)
{
	var eo=window[on];
	if(!Page.Validate(on))
		return;
	Page.HideAction(st, sid);
	var r=Page.GetObject(on, eo);
	ajax(r,ocf);
}