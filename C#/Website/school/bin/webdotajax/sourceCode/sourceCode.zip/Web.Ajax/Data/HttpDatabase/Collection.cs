﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.IO;

namespace Web.Ajax.Data.HttpDatabase
{
	public class Collection
	{
		public string PhysicalPath;
		public Collection(string physicalPath)
		{
			PhysicalPath = physicalPath;
		}

		public static Hashtable[] Get()
		{
			return null;
		}

		public void EnsureIndexes()
		{
			var il=Index.Get(PhysicalPath);
			foreach (var i in il)
			{
				i.Ensure();
			}
		}

		public void CheckConstraints(Hashtable o)
		{
			var cl = Constraint.Get(PhysicalPath);
			foreach (var c in cl)
			{
				c.Check(o);
			}
		}

		public void EnsureCollection()
		{
			if (!Directory.Exists(PhysicalPath))
			{
				Directory.CreateDirectory(PhysicalPath);
			}
		}

	}
}
