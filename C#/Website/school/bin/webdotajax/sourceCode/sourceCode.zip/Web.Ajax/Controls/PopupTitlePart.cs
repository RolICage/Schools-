using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace Web.Ajax.Controls
{
	public abstract class PopupTitlePart :  CompositeControl
	{
		#region Rendered
		/// <summary>
		/// Indicates if the control has already been rendered in this life cycle. 
		/// </summary>
		public bool Rendered = false;
		#endregion

		#region Render
		/// <summary>
		/// Renders the control if it has not been rendered already.
		/// </summary>
		/// <param name="writer">A HtmlTextWriter writer</param>
		public new void Render(HtmlTextWriter writer)
		{
			if (Rendered)
				return;
			base.Render(writer);
			Rendered = true;
		}
		#endregion

		public string PopupJavascriptId = "";
		
		public new string Width = "width:33%;";

		#region RenderBeginTag
		public override void RenderBeginTag(HtmlTextWriter writer)
		{
			writer.Write("<td class=\"" + CssClass + "\" style=\"" + Width + "\" ");
			if(!string.IsNullOrEmpty(PopupJavascriptId))
				writer.Write("id=\""+PopupJavascriptId+"_"+GetType().Name+"\"");
			writer.Write(">");
		} 
		#endregion

		#region RenderEndTag
		public override void RenderEndTag(HtmlTextWriter writer)
		{
			writer.Write("</td>");
		} 
		#endregion
	}
}
